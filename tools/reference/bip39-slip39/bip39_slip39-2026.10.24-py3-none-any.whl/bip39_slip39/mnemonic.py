# Copyright (c) The btclib developers
# Distributed under the MIT software license, see the accompanying
# LICENSE file or https://opensource.org/license/mit for the full text.

"""Mnemonic sentence conversion from/to sequence of integer indexes."""

from __future__ import annotations

import os
import threading
import unicodedata
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Literal, NamedTuple

from bip39_slip39._utils import assert_type, is_integer
from bip39_slip39.exceptions import (
    Bip39Slip39TypeError,
    Bip39Slip39ValueError,
)

__all__ = [
    "BIP39_LANGUAGE_FILES",
    "DEFAULT_LANGUAGE_FILES",
    "WORDLISTS",
    "Mnemonic",
    "MnemonicLang",
    "WordList",
    "WordLists",
    "data_file",
    "indexes_from_mnemonic",
    "mnemonic_from_indexes",
    "normalize_mnemonic",
]

WordList = Sequence[str]


class _Language(NamedTuple):
    """The words of a language and the index of each, which belong together."""

    words: list[str]
    # the index of every word, so that a lookup is not a scan of 2048
    # strings: indexes_from_mnemonic does one per word, and
    # lang_from_mnemonic one per word per language
    positions: dict[str, int]


def _filename(filename: object) -> str:
    """Return a file name as a str, a path object included.

    A `pathlib.Path` names a file as well as its str does, and is read
    the same way, so it is taken rather than refused; anything else, a
    path object of bytes included, is a type the parameter does not take.
    """
    name = os.fspath(filename) if isinstance(filename, os.PathLike) else filename
    if not isinstance(name, str):
        raise Bip39Slip39TypeError(f"invalid filename type: {type(name).__name__}")
    return name


def data_file(filename: str | os.PathLike[str]) -> str:
    """Return the path of a word-list this package ships."""
    return str(Path(__file__).parent / "_data" / _filename(filename))


# The word-lists of BIP39's reference implementation, keyed by ISO
# 639-1 code. Most are bip-0039/'s own; russian and turkish are in
# trezor/python-mnemonic and on no page of the BIP, which is what makes
# them a way to read what that implementation writes rather than a
# language to reach for when generating -- and BIP39 itself says
# non-English word-lists are strongly discouraged for generating.
#
# "zh" is Simplified Chinese, which is also the Chinese electrum reads;
# Traditional is "zh_tw". The two share 1275 of their 2048 words, so a
# Chinese sentence is ambiguous between them about once in three hundred,
# and that is the case lang_from_mnemonic has to answer for.
BIP39_LANGUAGE_FILES = {
    "cs": data_file("czech.txt"),
    "en": data_file("english.txt"),
    "es": data_file("spanish.txt"),
    "fr": data_file("french.txt"),
    "it": data_file("italian.txt"),
    "ja": data_file("japanese.txt"),
    "ko": data_file("korean.txt"),
    "pt": data_file("portuguese.txt"),
    "ru": data_file("russian.txt"),
    "tr": data_file("turkish.txt"),
    "zh": data_file("chinese_simplified.txt"),
    "zh_tw": data_file("chinese_traditional.txt"),
}

# every BIP39 and SLIP-0039 word-list this package ships: BIP39's and
# slip39's, which is a scheme and not a language code, as its key says.
# SLIP-0039 supports no localization at all, so there is no "en" of it to
# collide with BIP39's -- which is a different list of a different length,
# 1024 words of ten bits against 2048 of eleven. It is registered here
# rather than on a private WordLists built by slip39.py so that the lists
# of both schemes are reachable from the one place that holds them;
# electrum's own Portuguese and pre-2.0 English lists are electrum.py's,
# outside this registry. Sharing the registry is what lets a caller ask
# bip39 for lang="slip39", so bip39 refuses any list that is not 2048
# words long rather than answer with a base-1024 sentence no BIP39 wallet
# reads
DEFAULT_LANGUAGE_FILES = {
    **BIP39_LANGUAGE_FILES,
    "slip39": data_file("wordlist.txt"),
}

# The keys of DEFAULT_LANGUAGE_FILES, which are those of a fresh
# WORDLISTS: tests/mnemonic_test.py checks the two stay equal.
#
# Open: WordLists.load_lang adds a language, so the `lang: str`
# parameters of this module, bip39 and electrum stay str -- a Literal
# there would reject the file a caller has just loaded
MnemonicLang = Literal[
    "cs",
    "en",
    "es",
    "fr",
    "it",
    "ja",
    "ko",
    "pt",
    "ru",
    "tr",
    "zh",
    "zh_tw",
    "slip39",
]


class WordLists:
    """Class for word-lists to be used in entropy/mnemonic conversions.

    The word-lists loaded by default are DEFAULT_LANGUAGE_FILES: the
    languages of BIP39's reference implementation, plus slip39's. More can
    be added, or an existing language pointed at another file, with the
    load_lang method; a caller wanting an altogether different set -- as
    electrum.py does, electrum's Portuguese not being BIP39's -- passes
    language_files to the constructor.

    The keys above are what MnemonicLang names, and
    load_lang is why no lang parameter here or in bip39 and electrum is
    typed with it: the set is open, so a Literal would reject the
    language a caller has just loaded (issue btclib-org/btclib#216).

    Word-lists are loaded only if needed and read only once from disk,
    unless load_lang is given a file that replaces the registered one.
    Each word is NFKD-normalized as it is read, which is the form BIP39
    requires and the form electrum normalizes to, so a word looked up in
    either form is found; a '#' starts a comment, which is what carries
    the licence header of electrum's Portuguese list.

    power_of_two says whether the word count must be one. A BIP39 index
    is eleven bits, so for BIP39 it must; electrum converts to base
    len(wordlist) instead, and its Portuguese list has 1626 words, so for
    electrum it must not.

    A language is one record, its words and the index of each, and
    load_lang replaces it in a single store. A reader therefore sees the
    words, the index and the length of one load, never of two, and never
    an empty record that a load is about to fill: a second thread would
    otherwise get an *empty* word-list, mnemonic_from_indexes would refuse
    every index and indexes_from_mnemonic would call every word unknown.
    A non-empty record is a finished load, so a call given no filename
    skips the lock. A load, and any call given a filename, takes it, so
    that a language is registered once and its file and its record change
    together.

    A caller outside the package that reads the length and the words in
    two public calls can still pair those of two loads, if a third thread
    replaces the language between them. Each conversion in the package
    takes its length and its words or positions from one read of the record.

    The module-level WORDLISTS is a singleton, and load_lang mutating it
    affects every caller in the process: adding a language, or pointing an
    existing one at another file, is a process-wide decision. Callers
    wanting a private set can build their own WordLists().
    """

    def __init__(
        self,
        language_files: Mapping[str, str | os.PathLike[str]] | None = None,
        power_of_two: bool = True,
    ) -> None:
        self._lock = threading.Lock()
        self.power_of_two = power_of_two
        assert_type(language_files, (Mapping, type(None)), "language_files")
        files = language_files or DEFAULT_LANGUAGE_FILES
        for lang in files:
            assert_type(lang, str, "language")
        self.language_files = {lang: _filename(name) for lang, name in files.items()}
        self.languages = list(self.language_files)

        # each language starts with an empty record, which load_lang replaces
        self._language = {lang: _Language([], {}) for lang in self.languages}

    def load_lang(
        self, lang: str, filename: str | os.PathLike[str] | None = None
    ) -> None:
        """Load a language word-list, or add or replace one from filename.

        A registered language given no filename is read once, from its
        registered file; given filename, it is read from that file, which
        becomes the language's file. A new language needs filename.

        Every function taking a `lang` reaches it here, so this is where a
        `lang` of another type is refused: unchecked, it would be a
        language never seen and with no file, and refused as a missing file.
        """
        assert_type(lang, str, "lang")
        # a non-empty record is a finished load: the class docstring says why
        record = self._language.get(lang)
        if filename is None and record is not None and record.words:
            return
        path = None if filename is None else _filename(filename)
        with self._lock:
            known = lang in self.languages
            # language has been loaded already, with no replacement asked for
            if known and self._language[lang].words and path is None:
                return
            if known and path is None:
                path = self.language_files[lang]
            elif path is None:
                # the language is not quoted: a caller who passed a secret
                # in the wrong position would have it repeated
                raise Bip39Slip39ValueError("Missing file for an unknown language")

            words = self._read_wordlist(path)

            # a language is registered once its file has been read and
            # accepted, and not before: one left behind by a load that
            # raised would raise again on every call, langs_of_words
            # asking each language in turn whether it holds a word
            if not known:
                self.languages.append(lang)
            self.language_files[lang] = path
            # one store: a reader holding the old record keeps a whole one
            self._language[lang] = _Language(
                words, {word: i for i, word in enumerate(words)}
            )

    def _read_wordlist(self, filename: str) -> list[str]:
        """Return the words of a word-list file, NFKD and comments dropped."""
        # utf-8 and not ascii: most word-lists are not ascii, japanese and
        # korean not even close, and the BIP publishes them NFKD-encoded.
        # A '#' starts a comment, which is what carries the licence
        # header of electrum's Portuguese list
        try:
            with Path(filename).open(encoding="utf-8") as file_:
                lines = file_.readlines()
        except UnicodeDecodeError:
            # from None: the exception carries the bytes it could not read
            err_msg = "invalid wordlist file: not UTF-8"
            raise Bip39Slip39ValueError(err_msg) from None
        except (OSError, ValueError) as error:
            err_msg = f"cannot read wordlist file: {type(error).__name__}"
            raise Bip39Slip39ValueError(err_msg) from None
        stripped = (line.split("#")[0].strip() for line in lines)
        words = [unicodedata.normalize("NFKD", word) for word in stripped if word]

        nwords = len(words)
        # http://www.graphics.stanford.edu/~seander/bithacks.html
        if self.power_of_two and nwords & (nwords - 1) != 0:
            err_msg = f"invalid wordlist length: {nwords}, not a power of two"
            raise Bip39Slip39ValueError(err_msg)
        return words

    def _record(self, lang: str) -> _Language:
        """Return the record of a language, loaded.

        The one read of a language: a caller needing more than one of its
        words, its length and its positions takes them from the record it
        gets here, so that they are those of one load.
        """
        self.load_lang(lang)
        return self._language[lang]

    def wordlist(self, lang: str) -> WordList:
        """Return the language word-list."""
        return self._record(lang).words

    def language_length(self, lang: str) -> int:
        """Return the number of words in the language word-list."""
        return len(self._record(lang).words)

    def index(self, word: str, lang: str) -> int:
        """Return the index of a word into the language word-list.

        The refusal does not quote the word: it is one word of a sentence
        that is somebody's secret, usually one or two letters from the
        right one, and an exception message is what ends up in a log or a
        crash report. indexes_from_mnemonic refuses an unknown word with
        its own message, which gives the word's position.
        """
        assert_type(word, str, "word")
        record = self._record(lang)
        # lang is quoted below: load_lang has matched it against the
        # registered languages
        normalized = unicodedata.normalize("NFKD", word)
        found = record.positions.get(normalized)
        if found is None:
            raise Bip39Slip39ValueError(f"unknown '{lang}' word")
        return found

    def words_with_prefix(self, prefix: str, lang: str) -> list[str]:
        """Return the words of the language that begin with a prefix.

        In list order. An empty answer is a miss, one word is a completion,
        and the letters that can follow the prefix are read off the answer.
        An empty prefix answers every word, and a word is a prefix of
        itself.

        The prefix is normalized to NFKD as `index` normalizes a word, so
        that a composed spelling finds the decomposed words of the list.
        """
        assert_type(prefix, str, "prefix")
        words = self._record(lang).words
        normalized = unicodedata.normalize("NFKD", prefix)
        return [word for word in words if word.startswith(normalized)]

    def langs_of_words(self, words: Sequence[str]) -> list[str]:
        """Return the languages whose word-list holds every word.

        Every language is read from disk, the question being about all of
        them; a caller that knows the language names it instead of asking.
        """
        _assert_words(words)
        return self._langs_of(words, None)

    def _langs_of(self, words: Sequence[str], length: int | None) -> list[str]:
        """Return the languages holding every word, of that length if given.

        The length and the words are those of one read of the language.
        """
        normalized = [unicodedata.normalize("NFKD", word) for word in words]
        langs = []
        for lang in self.languages:
            record = self._record(lang)
            if length is not None and len(record.words) != length:
                continue
            positions = record.positions
            if all(word in positions for word in normalized):
                langs.append(lang)
        return langs


def _assert_words(words: object) -> None:
    """Refuse anything but a sequence of str, a lone str included.

    A str is itself a sequence of str, so a sentence passed where its
    words were meant would be read one character at a time: slip39's
    `_assert_mnemonic_sequence` refuses a lone mnemonic for that reason.
    """
    if isinstance(words, str) or not isinstance(words, Sequence):
        raise Bip39Slip39TypeError(f"invalid words type: {type(words).__name__}")
    for word in words:
        assert_type(word, str, "word")


def _assert_indexes(indexes: object) -> None:
    """Refuse anything but a sequence of integers, a str and a bool included.

    `object` and not `Sequence[int]`, which would leave mypy proving the
    str case unreachable: it is reachable from any caller mypy never saw.
    """
    if isinstance(indexes, str) or not isinstance(indexes, Sequence):
        raise Bip39Slip39TypeError(f"invalid indexes type: {type(indexes).__name__}")
    for index in indexes:
        if not is_integer(index):
            raise Bip39Slip39TypeError(f"invalid index type: {type(index).__name__}")


# singleton
WORDLISTS = WordLists()

Mnemonic = str


def normalize_mnemonic(mnemonic: Mnemonic) -> Mnemonic:
    r"""Return the mnemonic as read here, whatever separates its words.

    NFKD first, then every run of unicode whitespace becomes one space,
    so that `" abandon  abandon\tabandon "` and
    `"abandon abandon abandon"` are the same sentence and reach the same
    seed. BIP39 mandates the NFKD and describes words separated by
    spaces, but says nothing about a doubled space, a tab, or the newline
    a mnemonic wrapped across two lines of a paper backup carries.

    The NFKD comes first, and not merely because BIP39 asks for it.
    U+3000, the ideographic space BIP39's own Japanese vectors separate
    words with, decomposes to U+0020, so the separator question is
    answered by the normalization the spec already requires rather than
    by a rule of this package's; and normalizing first leaves no run of
    whitespace for the collapse to miss, which the other order does --
    U+00A8 decomposes to a space plus a combining diaeresis, so
    collapsing before normalizing hands PBKDF2 two adjacent spaces.

    Refusing anything but a single space is the other defensible
    position, and it is what the reference implementation reads: trezor's
    python-mnemonic splits on `" "`, so a doubled space is an empty word
    and an error. It is not taken here because that implementation is
    strict only where it checks a mnemonic -- its `to_seed` applies NFKD
    and nothing else, so a leading space or a trailing newline stretches
    into a *different seed* with no complaint, and an unreadable wallet
    is the one outcome worse than a refusal. Collapsing cannot do that,
    and it refuses nothing a wallet, a mail client or an editor can
    plausibly produce.

    Zero-width characters stay: U+200B and U+FEFF carry no White_Space
    property and survive NFKD, so a word holding one is an unknown word
    rather than two words -- which is a refusal, the safe answer, and not
    a silently different seed.

    This is not electrum's normalization, and cannot be: `electrum.py`
    lower-cases, drops the combining characters and joins words that NFKD
    left either side of a space between two CJK characters. Dropping
    combining characters undoes the very decomposition BIP39 requires, so
    the two schemes need two functions, and electrum keeps its own.
    """
    assert_type(mnemonic, str, "mnemonic")
    return " ".join(unicodedata.normalize("NFKD", mnemonic).split())


def mnemonic_from_indexes(
    indexes: Sequence[int],
    lang: str,
    wordlists: WordLists = WORDLISTS,
    separator: str = " ",
) -> Mnemonic:
    """Return the mnemonic from a list of word-list integer indexes.

    Return the mnemonic from a list of integer indexes into a given
    language word-list.

    An index out of the word-list's range is refused by its position and
    not by its value, which is a digit of the secret the sentence spells.
    """
    _assert_indexes(indexes)
    assert_type(wordlists, WordLists, "wordlists")
    return _mnemonic_in(wordlists._record(lang), indexes, separator)


def _mnemonic_in(record: _Language, indexes: Sequence[int], separator: str) -> Mnemonic:
    """Return the mnemonic of indexes into the words of a record."""
    wordlist = record.words
    for position, index in enumerate(indexes, 1):
        if not 0 <= index < len(wordlist):
            err_msg = f"invalid index at position {position}: "
            err_msg += f"not in [0, {len(wordlist)})"
            raise Bip39Slip39ValueError(err_msg)
    return separator.join(wordlist[index] for index in indexes)


def indexes_from_mnemonic(
    mnemonic: Mnemonic, lang: str, wordlists: WordLists = WORDLISTS
) -> list[int]:
    """Return the word-list integer indexes for a given mnemonic.

    Return the list of integer indexes into a language word-list for a
    given mnemonic. The sentence is split on any whitespace, the
    ideographic space of a japanese mnemonic included.
    """
    assert_type(mnemonic, str, "mnemonic")
    assert_type(wordlists, WordLists, "wordlists")
    # loaded first, so that an unknown language is refused as itself and
    # not as the unknown word _indexes_in would call it
    return _indexes_in(wordlists._record(lang), mnemonic, lang)


def _indexes_in(record: _Language, mnemonic: Mnemonic, lang: str) -> list[int]:
    """Return the indexes of the words of a mnemonic in a record."""
    indexes = []
    for position, word in enumerate(mnemonic.split(), 1):
        found = record.positions.get(unicodedata.normalize("NFKD", word))
        if found is None:
            err_msg = f"unknown '{lang}' word at position {position}"
            raise Bip39Slip39ValueError(err_msg)
        indexes.append(found)
    return indexes
