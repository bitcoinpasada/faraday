# Copyright (c) The btclib developers
# Distributed under the MIT software license, see the accompanying
# LICENSE file or https://opensource.org/license/mit for the full text.

"""The canonical form of a bitcoin key, parsed once and carried.

**What this is for.** A public key has several spellings -- SEC octets, a
hex string of them, a point, an xpub -- and a private key has as many.
Each is read where its format is defined, and what a read answers is a
scalar, a point or a tuple of them with a network: the canonical form is
what comes *out* of a conversion and never what goes *in*, so a caller
that has one has to spell it back for the next call, which parses it
again. That round trip is what `btclib_wallet.bip32.derive_` and
`ecc.curves.sec_point._sec_from_pub_key` work around locally --
issues 886 and 887. Issue 896 is the same round trip where
`script.taproot` reads an internal key: it takes a `PubKeyData`, and the
single lift of its x is ecc's `pub_key_tweak_add_var`.

`PubKeyData` and `PrvKeyData` are that cut: the spellings stay at the
boundary, the parse happens once, and what travels afterwards is an
object that knows which half it is.

**Why the SEC octets are the field and the point is derived.** The two
conversions do not cost the same. Serializing a point is a byte
concatenation; parsing a compressed one is a modular square root, whose
cost `ecc.curves.sec_point.point_from_octets_var` records beside the
two arms that pay it. A write is cheaper than a lift and a lift than a
derivation. The first of those two gaps is widest exactly where it
matters, at the compressed form that bitcoin uses.

So the cheap direction is paid on the way in, the dear one on first use
and kept, and `PrvKeyData.pub` is where laziness buys most. The CHANGELOG
entry for this module carries the measurements and the command that took
them: one fact in one place, and this is not the place.

That is not only a cache. **`point_var` is also the proof**: a length and a
prefix are what the constructor checks, and whether those octets are a
point of the curve is the question `point_var` answers. It is the contract
`ecc.curves.sec_point._sec_from_pub_key` already states -- "the
guarantee is the caller's to complete" -- made explicit and paid once,
rather than left to each caller and paid again at every one.

**Why one type and not two.** A `PubKeySecData` beside a `PubKeyPointData`
would hand the caller a choice that is a cache decision rather than a
meaning, which is the burden this module exists to remove; any function
taking either would take a union again; and the same key in the two types
could not compare equal without performing the very conversion the split
was meant to avoid.

**Why frozen, and why not `slots=True`.** Frozen for the reason
`BIP32KeyData` is (issue 727): no field changes after construction, so
an object built with checks on stays valid, and one built with
`check_validity=False` has to be asked by whichever public name uses it,
as `PrvKeyData.pub` and `bms.sign` ask a private key and `b58.p2pkh`
asks a public one. Not slotted, because
`functools.cached_property` stores into the instance `__dict__` and a
slotted dataclass has none -- it raises `TypeError: No '__dict__'
attribute`. Equality and hashing read the declared fields alone, so what
a lazy property has computed never changes either, and two objects for
one key compare equal whichever of them has been asked for a point.

The compressed and uncompressed spellings of one key are **not** equal
here, and that is right rather than an oversight: they hash to different
addresses.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property

from ecc.curves import Curve, bytes_from_prv_key_int, point_from_octets_var
from typing_extensions import override

from btclib.alias import Octets, Point
from btclib.exceptions import BTClibTypeError, BTClibValueError
from btclib.network import NETWORKS, network_from_name, normalized_network_name
from btclib.utils import assert_type, bytes_from_octets, is_integer

__all__ = [
    "PrvKeyData",
    "PubKeyData",
]

# the two SEC forms, and the prefix each one takes. 0x04 is the
# uncompressed marker; 0x02 and 0x03 name the parity of y. A hybrid key --
# 0x06 or 0x07, both coordinates *and* a parity byte -- is SEC1 and is not
# among them: `sec_point.point_from_octets_var` does parse one when its
# `hybrid` argument asks for it, the script engine being the caller that
# has to accept what was mined, and it defaults to `hybrid=False` because
# nothing in bitcoin produces one. This type takes that default, so a
# hybrid key is refused here rather than carried as a canonical form.
# `script.taproot`'s internal key reads `_HYBRID_PREFIXES` directly for
# the same refusal, ahead of the bindings/Python split: `check_validity`
# is off for that key, so this module's own proof never runs for it, and
# a hybrid prefix is the one spelling libsecp256k1 parses that btclib's
# stated policy does not (issue #1227)
_COMPRESSED_PREFIXES = (0x02, 0x03)
_UNCOMPRESSED_PREFIX = 0x04
_HYBRID_PREFIXES = (0x06, 0x07)


@dataclass(frozen=True, init=False)
class PubKeyData:
    """A public key as its SEC octets, on a named network.

    The octets are the field because serializing a point is cheap and
    parsing one is not; `point_var` is the lift, paid on first use and kept.
    The module docstring carries the reasoning and the CHANGELOG entry
    the measurements.
    """

    sec: bytes
    network: str

    def __init__(
        self,
        sec: Octets,
        network: str = "mainnet",
        *,
        check_validity: bool = True,
    ) -> None:
        # the field is declared `bytes` and `bytes_from_octets` is what
        # makes it one: a key made from a bytearray would be unhashable,
        # where the docstring above promises that equality and hashing
        # read the declared fields, and one made from a memoryview would
        # carry octets no concatenation accepts -- `script.taproot` joins
        # a merkle root to the x it reads off `sec` before hashing the
        # pair under a tag
        object.__setattr__(self, "sec", bytes_from_octets(sec))
        # the two fields are asymmetric in what they inherit from their
        # converter: `bytes_from_octets` refuses a wrong type whatever
        # `check_validity` says, where `normalized_network_name` refuses
        # nothing and leaves the refusal to `assert_valid`. Without the
        # coercion, " MainNet " and "mainnet" build keys that are not
        # equal and do not hash alike, and the docstring above -- equality
        # reads the declared fields -- would be true of the fields and
        # false of the key
        object.__setattr__(self, "network", normalized_network_name(network))

        if check_validity:
            self.assert_valid()

    @property
    def is_compressed(self) -> bool:
        """Answer whether the key is in the compressed SEC form.

        `is_` and not `compressed`, which is what `PrvKeyData` calls the
        same idea: there it is a field, a kind the caller states and a
        WIF carries, and here it is a question about octets already in
        hand. CONTRIBUTING.md's vocabulary is what makes the two names
        differ, and the difference is the point.
        """
        return len(self.sec) == self.curve.p_size + 1

    @property
    def curve(self) -> Curve:
        """Return the curve of the network the key is on."""
        return network_from_name(self.network).curve

    @cached_property
    def point_var(self) -> Point:
        """Return the curve point the octets encode, lifting it once.

        The lift is the proof: `assert_valid` reads a length and a
        prefix, and whether what they frame is a point of the curve is
        what this answers. A key nobody asks this of has never been
        proved one -- deliberately, that being the trade
        `ecc.curves.sec_point._sec_from_pub_key` already makes for
        the callers that hand the octets straight to a call which parses
        them anyway.
        """
        return point_from_octets_var(self.sec, self.curve)

    def assert_valid(self) -> None:
        """Refuse octets no SEC public key has, and an unknown network.

        A length and a prefix, and not a point: see `point_var`, which is
        where the curve is asked. That `sec` is bytes at all is not asked
        here, `bytes_from_octets` having refused anything else in the
        constructor whatever `check_validity` said; `network` is asked,
        `normalized_network_name` being a coercion that refuses
        nothing.
        """
        assert_type(self.network, str, "network")
        # refuses a name no network has, which is what this is called for
        ec = network_from_name(self.network).curve
        if len(self.sec) == ec.p_size + 1:
            if self.sec[0] not in _COMPRESSED_PREFIXES:
                raise BTClibValueError(
                    f"invalid compressed SEC prefix: {self.sec[0]:#04x}"
                )
        elif len(self.sec) == 2 * ec.p_size + 1:
            if self.sec[0] != _UNCOMPRESSED_PREFIX:
                raise BTClibValueError(
                    f"invalid uncompressed SEC prefix: {self.sec[0]:#04x}"
                )
        else:
            # never echo the octets: a caller that reached here with
            # private material spelled them as a public key by mistake,
            # and the size is the whole of what is wrong
            raise BTClibValueError(f"invalid SEC key size: {len(self.sec)}")


@dataclass(frozen=True, init=False)
class PrvKeyData:
    """A private key as its scalar, on a named network, compressed or not.

    `compressed` is not decoration: it is what a WIF carries and what
    decides the SEC form of `pub`, so without it the public key this
    derives would not be one key but two.

    `pub` is the derivation, and it is the most expensive conversion in
    this module -- a scalar multiplication, dearer than lifting a
    compressed point -- so it is where laziness pays most.
    """

    q: int
    network: str
    compressed: bool

    def __init__(
        self,
        q: int,
        network: str = "mainnet",
        compressed: bool = True,
        *,
        check_validity: bool = True,
    ) -> None:
        object.__setattr__(self, "q", q)
        object.__setattr__(self, "network", normalized_network_name(network))
        object.__setattr__(self, "compressed", compressed)

        if check_validity:
            self.assert_valid()

    @override
    def __repr__(self) -> str:
        # never echo private key material, as BIP32KeyData's repr does not;
        # show the network only if it is a known name: swapped arguments
        # put a key there when validity is not checked. The type is checked
        # first, so no foreign __eq__ or __hash__ runs
        net: object = self.network
        shown = repr(net) if isinstance(net, str) and net in NETWORKS else "..."
        masked = f"{type(self).__name__}(q=..., network={shown}"
        return f"{masked}, compressed={self.compressed!r})"

    @property
    def curve(self) -> Curve:
        """Return the curve of the network the key is on."""
        return network_from_name(self.network).curve

    @cached_property
    def pub(self) -> PubKeyData:
        """Return the public key this one derives, multiplying once.

        The key is asked first, whatever `check_validity` it was built
        with, as `bms.sign` asks the key it is handed: an object built
        with `check_validity=False` has never been asked, and
        `bytes_from_prv_key_int` reduces its scalar mod n and reads a hex
        string as one, so an out-of-range `q` would otherwise derive the
        public key of a different scalar, silently.

        The `PubKeyData` is built with `check_validity=False`, the one
        call in this module entitled to it: its octets are the
        serialization just written, and its network is the name
        `assert_valid` has just resolved.
        """
        self.assert_valid()
        sec = bytes_from_prv_key_int(self.q, self.curve, self.compressed)
        return PubKeyData(sec, self.network, check_validity=False)

    def assert_valid(self) -> None:
        """Refuse a scalar outside 1..n-1, and an unknown network."""
        assert_type(self.network, str, "network")
        # `is_integer` and not `assert_type(self.q, int, "q")`: a bool is
        # an int to `isinstance`, and here the two mean different things
        # -- `compressed` is a kind and `q` is a number -- so True
        # reaching the scalar is a caller's mistake and not the key one.
        # That policy is one decision for the whole library, which
        # `utils.is_integer` states and `integer_policy_test.py` keeps
        if not is_integer(self.q):
            raise BTClibTypeError("not a private key scalar")
        assert_type(self.compressed, bool, "compressed")
        ec = network_from_name(self.network).curve
        if not 0 < self.q < ec.n:
            # never echo the scalar: it is the secret itself
            raise BTClibValueError("private key not in 1..n-1")
