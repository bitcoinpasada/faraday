# Copyright (c) The btclib developers
# Distributed under the MIT software license, see the accompanying
# LICENSE file or https://opensource.org/license/mit for the full text.

"""Taproot keys, script trees and control blocks, per BIP341.

The output side and the spend side of taproot, tapscript execution
excepted: output_pubkey and output_prvkey build the tweaked keys,
tree_helper and input_script_sig walk a script tree into leaves,
merkle paths and control blocks, check_output_pubkey verifies one,
and serialize/parse are the tapscript codec the engine reads.
"""

from __future__ import annotations

from io import BytesIO
from typing import cast

from ecc.curves import bytes_from_prv_key_int, scalar_from_prv_key, secp256k1
from ecc.ecc.ssa import prv_key_tweak_add, pub_key_tweak_add_var
from ecc.exceptions import EccValueError
from ecc.hashes import tagged_hash

from btclib import var_bytes
from btclib.alias import (
    BinaryData,
    Integer,
    Octets,
    ScriptList,
    TaprootLeafPaths,
    TaprootScriptTree,
)
from btclib.exceptions import (
    BTClibTypeError,
    BTClibValueError,
    ScriptError,
    ScriptErrorCode,
)
from btclib.key import _HYBRID_PREFIXES, PubKeyData
from btclib.script.limits import MAX_SCRIPT_ELEMENT_SIZE
from btclib.script.op_codes_tapscript import (
    OP_CODE_NAMES,
    OP_SUCCESS,
    _serialize_str_command,
)
from btclib.script.script import _serialize_bytes_command, _serialize_int_command
from btclib.utils import (
    _message_text,
    assert_type,
    bytes_from_octets,
    bytesio_from_binarydata,
    is_integer,
)

__all__ = [
    "MAX_TREE_DEPTH",
    "assert_valid_control_block",
    "check_output_pubkey",
    "input_script_sig",
    "leaf_hash",
    "output_prvkey",
    "output_prvkey_from_merkle_root",
    "output_pubkey",
    "output_pubkey_from_merkle_root_var",
    "parse",
    "serialize",
    "tree_helper",
]

# How deep a script tree may be, which is Core's
# TAPROOT_CONTROL_MAX_NODE_COUNT in script/interpreter.h. One number for
# two things that cannot differ: a leaf at depth d is proved by a merkle
# path of d nodes, and the control block carrying that path is capped at
# TAPROOT_CONTROL_MAX_SIZE = 33 + 32 * 128 -- so a leaf deeper than this
# has no control block to be spent with. tree_helper refuses such a tree,
# as Core's TaprootBuilder never builds one: `ValidDepths` answers false
# for it and `Insert` asserts against it, in script/signingprovider.cpp.
#
# Here rather than in script/limits.py, whose caps are the ones at
# the top of Core's script/script.h: this one is BIP341's, declared
# beside the control block it bounds and read by the descriptor parser
# through this name
MAX_TREE_DEPTH = 128


def serialize(script: ScriptList) -> bytes:
    """Serialize a tapscript from its commands.

    The tapscript twin of script.serialize, differing where BIP342
    differs: the OP_SUCCESSx names exist here, and one must be followed
    by exactly one bytes command, appended raw -- what follows an
    OP_SUCCESS need not be a script, so it round-trips unparsed.
    """
    # what is not a list reached the reversal and the `pop` below
    # untouched, so a None was "not subscriptable" and a str was a str with
    # no `pop` -- neither of them a word about the script
    assert_type(script, list, "tapscript")

    r: list[bytes] = []
    script = script[::-1]
    while script:
        command = script.pop()
        if isinstance(command, int):
            r.append(_serialize_int_command(command))
        elif isinstance(command, str):
            serialized = _serialize_str_command(command)
            r.append(serialized)
            # keyed on the byte written, not on how the command spells it
            if len(serialized) == 1 and serialized[0] in OP_SUCCESS:
                if len(script) != 1 or not isinstance(
                    script[0], (bytes, bytearray, memoryview)
                ):
                    raise BTClibValueError(
                        "OP_SUCCESS must be followed by a single bytes command"
                    )
                return b"".join(r) + script[0]
        else:  # must be bytes
            r.append(_serialize_bytes_command(command))
    return b"".join(r)


def _read_push_data(s: BytesIO, i: int) -> bytes:
    """Read the data of the push whose first byte is i, 0 < i <= 78.

    The 520-byte element limit is not checked here, and script.parse
    checks none: an OP_SUCCESS makes a tapscript valid whatever else it
    holds, so only the caller -- which knows whether one has been met --
    can turn an oversized element into a refusal.
    """
    data_length = i  # 0 < i < 76 -> 1-byte-data-length | data
    if i > 75:
        # i == 76 -> OP_PUSHDATA1 | 1-byte-data-length | data
        # i == 77 -> OP_PUSHDATA2 | 2-byte-data-length | data
        # i == 78 -> OP_PUSHDATA4 | 4-byte-data-length | data
        size = 2 ** (i - 76)
        y = s.read(size)
        if len(y) != size:
            raise ScriptError("Invalid pushdata length", ScriptErrorCode.BAD_OPCODE)
        data_length = int.from_bytes(y, byteorder="little")
    data = s.read(data_length)
    if len(data) != data_length:
        raise ScriptError("Invalid pushdata length", ScriptErrorCode.BAD_OPCODE)
    return data


def parse(stream: BinaryData, exit_on_op_success: bool = False) -> ScriptList:
    """Parse a tapscript into its commands, per BIP342.

    An unknown op code is refused, data pushes come back as hex
    strings and a push of no data as OP_0, as in script.parse, and an
    OP_SUCCESSx ends the parse: what follows one is returned as raw
    bytes, BIP342 not requiring it to be a script --
    or, with `exit_on_op_success`, the whole answer is the single
    marker ["OP_SUCCESS"]. An element over 520 bytes is refused only by
    a parse that meets no OP_SUCCESSx, one anywhere making the script
    valid.

    Each refusal is a ScriptError with the code Core's interpreter gives
    the same fault: a push running past the end and an
    unknown op code are BAD_OPCODE, an oversized element PUSH_SIZE. The
    engine runs a tapscript without this parse.

    A `bool` and nothing else, which is the line
    `tests/built_object_contract_test.py` draws: this flag decides *what
    is computed* rather than whether a check runs, so a value read for
    its truth answered the marker where the commands were
    asked for -- two different readings of the same bytes.
    """
    assert_type(exit_on_op_success, bool, "exit_on_op_success")

    s = bytesio_from_binarydata(stream)
    r: ScriptList = []  # initialize the result list
    invalid_element_size = False

    while True:
        t = s.read(1)  # get one byte
        if not t:
            break
        i = t[0]  # convert the byte to an integer
        if 0 < i <= 78:  # push
            data = _read_push_data(s, i)
            # BIP342: an element over 520 bytes is invalid, but an
            # OP_SUCCESS anywhere makes the script valid without the rest
            # of it being executed, so the refusal waits for a parse that
            # ends without meeting one
            invalid_element_size |= len(data) > MAX_SCRIPT_ELEMENT_SIZE
            # an empty push is OP_0, as script.parse and serialize have it
            r.append(data.hex().upper() or OP_CODE_NAMES[0])
        elif i in OP_SUCCESS:  # OP_SUCCESSx
            if exit_on_op_success:
                return ["OP_SUCCESS"]
            # what follows an OP_SUCCESS is returned unparsed: BIP342 does
            # not require it to be a script at all
            r.append(f"OP_SUCCESS{i}")
            r.append(s.read())
            return r
        elif i in OP_CODE_NAMES:  # OP_CODE
            r.append(OP_CODE_NAMES[i])
        else:
            err_msg = f"unknown op code: {hex(i)}"
            raise ScriptError(err_msg, ScriptErrorCode.BAD_OPCODE)
    if invalid_element_size:
        raise ScriptError("Invalid pushdata length", ScriptErrorCode.PUSH_SIZE)
    return r


def leaf_hash(leaf_version: int, script: bytes) -> bytes:
    """Return the BIP341 tapleaf hash of a serialized leaf script.

    What names a leaf everywhere but in the control block: the merkle
    path is built from these, a BIP342 signature commits to one, and
    BIP371's psbt fields key their taproot data by one. `script` is the
    leaf script already serialized, which is the form all three of those
    hold it in.

    The leaf version is a byte whose low bit is the output key's parity
    in the control block, never the version's: BIP341 hashes
    `c[0] & 0xfe`, and Bitcoin Core's `TaprootBuilder::Add` asserts it
    even. An odd one names no leaf any spend can reveal, so it is
    refused rather than masked or hashed as given.
    """
    if not is_integer(leaf_version):
        err_msg = f"invalid leaf version type: {type(leaf_version).__name__}"
        raise BTClibTypeError(err_msg)
    if not 0 <= leaf_version <= 0xFE or leaf_version & 1:
        raise BTClibValueError(f"invalid leaf version: {_message_text(leaf_version)}")
    preimage = leaf_version.to_bytes(1, "big") + var_bytes.serialize(script)
    return tagged_hash(b"TapLeaf", preimage)


def tree_helper(script_tree: TaprootScriptTree) -> tuple[TaprootLeafPaths, bytes]:
    """Walk a script tree: (every leaf with its merkle path, root hash).

    BIP341's taproot_tree_helper: the leaves come back in tree order,
    each with the control-block path that proves it, and the root is
    what the output key commits to.

    Every node is asked for its shape before it is walked: a list, of
    one leaf or of two subtrees, a leaf being a `(leaf_version, script)`
    tuple. A node that is no list, a leaf that is no such tuple and a
    leaf version that is no integer are a BTClibTypeError; a list of
    neither one nor two elements, a leaf version outside a byte and a
    leaf deeper than MAX_TREE_DEPTH are a BTClibValueError.
    """
    return _walk(script_tree, 0)


def _walk(script_tree: TaprootScriptTree, depth: int) -> tuple[TaprootLeafPaths, bytes]:
    """`tree_helper` for a node at `depth`, the root being at 0."""
    assert_type(script_tree, list, "script tree")
    if len(script_tree) == 1:
        return _tree_helper(script_tree[0])
    if len(script_tree) != 2:
        err_msg = f"invalid script tree node: {len(script_tree)} elements, "
        raise BTClibValueError(err_msg + "neither one leaf nor two subtrees")
    # a branch puts its leaves one level below itself, and a leaf's depth
    # is the length of the merkle path proving it: refused here, before
    # the recursion, it also bounds the recursion well inside Python's
    if depth == MAX_TREE_DEPTH:
        raise BTClibValueError(f"script tree deeper than {MAX_TREE_DEPTH}")
    # a branch: both elements are subtrees, and the alias says only that
    # an element may also be a leaf, so the narrowing is ours to assert --
    # and the recursion's own `assert_type` is what refuses a leaf here
    left, left_h = _walk(cast("TaprootScriptTree", script_tree[0]), depth + 1)
    right, right_h = _walk(cast("TaprootScriptTree", script_tree[1]), depth + 1)
    info = [(leaf, c + right_h) for leaf, c in left]
    info += [(leaf, c + left_h) for leaf, c in right]
    if right_h < left_h:
        left_h, right_h = right_h, left_h
    return (info, tagged_hash(b"TapBranch", left_h + right_h))


def _tree_helper(leaf: object) -> tuple[TaprootLeafPaths, bytes]:
    # a tuple of two and not any pair that unpacks: a two-element list
    # holding a leaf version and a script is how a branch is spelled too.
    # The arity is the alias's, `tuple[int, ScriptList]`, so it is a type
    if not isinstance(leaf, tuple):
        raise BTClibTypeError(f"invalid script tree leaf type: {type(leaf).__name__}")
    if len(leaf) != 2:
        raise BTClibTypeError(f"invalid script tree leaf: {len(leaf)}-tuple")
    leaf_version, script = leaf
    if not is_integer(leaf_version):
        err_msg = f"invalid leaf version type: {type(leaf_version).__name__}"
        raise BTClibTypeError(err_msg)
    # the mask below would read 0x100 as 0x00 and -1 as 0xFE
    if not 0 <= leaf_version <= 0xFF:
        raise BTClibValueError(f"invalid leaf version: {_message_text(leaf_version)}")
    leaf_version &= 0xFE
    h = leaf_hash(leaf_version, serialize(script))
    return ([((leaf_version, script), b"")], h)


def _tap_tweak(pub_key: bytes, h: bytes) -> int:
    """Return the BIP341 tweak an x-only key and a tree hash commit to.

    One function for the three tweaks, the two that build an output and
    the one that checks a control block against it, so that the rule
    below cannot hold in one of them and not in another.
    """
    t = int.from_bytes(tagged_hash(b"TapTweak", pub_key + h), "big")
    # BIP341: fail if t is not smaller than the group order
    if t >= secp256k1.n:
        raise BTClibValueError("Invalid script tree hash")
    return t


def _output_pubkey_and_internal_key(
    internal_pubkey: PubKeyData | None, script_tree: TaprootScriptTree | None
) -> tuple[bytes, int, bytes]:
    """Return the output key, its parity, and the x-only internal key.

    What `output_pubkey` and `input_script_sig` want between them: the
    first answers the pair and drops the third, the second needs the
    internal key beside the parity. Read once, the key is parsed once,
    which is the redundancy issue 896 is about, one function further out.

    Sharing it is also what keeps the two answering for the same spellings
    of an internal key: a form accepted for the output key and refused for
    the control block that proves it would be refused one call after being
    accepted, and one reader cannot drift from another.
    """
    # None is what stands for either being absent, and nothing else is:
    # read for its truth, a falsy value of a wrong type -- b"", 0, [] --
    # would be taken for a missing key or a missing tree
    if internal_pubkey is None and script_tree is None:
        raise BTClibValueError("missing data")
    if internal_pubkey is not None:
        assert_type(internal_pubkey, PubKeyData, "internal_pubkey")
        # the 33-byte and the 65-byte form both arrive here, and `[1:33]`
        # is the x-coordinate of either
        sec = internal_pubkey.sec
        # A hybrid prefix is a third spelling of a compressed or
        # uncompressed key and not a malformed one (issue #1227). key.py's
        # paragraph on `_HYBRID_PREFIXES` is why the answer is refusal.
        # Asked ahead of `assert_valid` below, which refuses the prefix
        # too, so that the sentence names it as hybrid
        if sec[0] in _HYBRID_PREFIXES:
            raise BTClibValueError(
                f"invalid internal public key: hybrid SEC prefix {sec[0]:#04x}"
            )
        # `check_validity=False` is "do not check now" and not an
        # exemption (CONTRIBUTING.md), so the key is asked here: a length,
        # a prefix and a network name, no point lifted, the tweak's own
        # parse being the proof (issue 887)
        internal_pubkey.assert_valid()
        key_data = internal_pubkey
    else:
        h_str = "50929b74c1a04954b78b4b6035e97a5e078a5a0f28ec96d547bfee9ace803ac0"
        # BIP341's unspendable point is published as an x-only key and
        # nothing else, so the prefix is this module's to supply -- 02,
        # BIP341's lift being the even one
        key_data = PubKeyData(b"\x02" + bytes.fromhex(h_str), check_validity=False)
    h = b"" if script_tree is None else tree_helper(script_tree)[1]
    q, parity_bit = _tweaked_pubkey_var(key_data, h)
    return q, parity_bit, key_data.sec[1:33]


def output_pubkey(
    internal_pubkey: PubKeyData | None = None,
    script_tree: TaprootScriptTree | None = None,
) -> tuple[bytes, int]:
    """Return a taproot output key and its parity, per BIP341.

    The x-only internal key is tweaked by the script tree's root hash,
    a None tree contributing empty bytes -- key path only -- and a None
    internal key replaced by BIP341's unspendable point, script path
    only. An empty tree is no tree but a malformed one, as it is to
    tree_helper. The parity bit is the tweaked point's, needed by the
    control block and never serialized in the output.
    """
    q, parity_bit, _ = _output_pubkey_and_internal_key(internal_pubkey, script_tree)
    return q, parity_bit


def _tweaked_pubkey_var(pub_key: PubKeyData, h: bytes) -> tuple[bytes, int]:
    """Return the x-only key an internal key tweaked by h, and its parity.

    The half of BIP341's output key that does not care where h came
    from: a tree the caller built, or the merkle root a psbt carries.

    `ssa.pub_key_tweak_add_var` is this very operation, parity included.
    A compressed key goes to it as its x alone, unproven: the tweak's own
    parse is the proof, and a lift first would be a second square root of
    one x (issue 887). An uncompressed key goes whole, so that its y is
    proved to be its x's. The refusal is ecc's class, read into btclib's.
    """
    t = _tap_tweak(pub_key.sec[1:33], h)
    key = pub_key.sec[1:33] if pub_key.is_compressed else pub_key.sec
    try:
        x_Q, parity = pub_key_tweak_add_var(key, t)
    except EccValueError as e:
        raise BTClibValueError(str(e)) from e
    return x_Q.to_bytes(32, "big"), parity


def output_pubkey_from_merkle_root_var(
    internal_pubkey: Octets, merkle_root: Octets = b""
) -> tuple[bytes, int]:
    """Return a taproot output key from a merkle root, per BIP341.

    `output_pubkey` with the root already in hand, which is the shape a
    psbt has it in: BIP371's `PSBT_IN_TAP_MERKLE_ROOT` is the root and
    not the tree that produced it, an input naming the branch it spends
    by its leaf script and control block instead -- so a signer that
    takes the key path is told the root and nothing else about the tree.
    An empty root is key path only, as an empty tree is.

    The internal key is x-only and 32 bytes, which is what BIP341 tweaks
    and what the psbt field holds; `output_pubkey` takes a `PubKeyData`,
    which is the whole key and not only the x BIP341 tweaks.
    """
    internal_pubkey = bytes_from_octets(internal_pubkey, 32)
    # 02 and not 03: x-only octets are all this caller has, and BIP341's
    # lift is the even one, so the prefix says what the key means rather
    # than adding anything to it
    return _tweaked_pubkey_var(
        # `assert_valid` reads a length and a prefix, and this call
        # settles both itself: the size is checked on the way in and the
        # prefix is the one supplied on the line below
        PubKeyData(b"\x02" + internal_pubkey, check_validity=False),
        bytes_from_octets(merkle_root),
    )


def output_prvkey(
    prv_key: Integer,
    script_tree: TaprootScriptTree | None = None,
) -> int:
    """Return the private key of the taproot output key, per BIP341.

    The private counterpart of output_pubkey: the internal key is
    negated where its public point has an odd y, then tweaked by the
    script tree's root hash, so its public point is the output key
    exactly.
    """
    # None for no tree, as output_pubkey reads it: the two answer for the
    # same trees, one being the other's private key
    h = b"" if script_tree is None else tree_helper(script_tree)[1]
    return _tweaked_prvkey(scalar_from_prv_key(prv_key), h)


def _tweaked_prvkey(internal_prvkey: int, h: bytes) -> int:
    """Return the private key an internal one tweaked by h.

    The private half of `_tweaked_pubkey_var`, h coming from the same two
    places: a tree the caller built, or the merkle root a psbt carries.
    `ssa.prv_key_tweak_add` negates the key whose public point has an
    odd y, as BIP341 requires, and adds the tweak. The refusal of a sum
    that is zero is ecc's class, read into btclib's.
    """
    x_P = bytes_from_prv_key_int(internal_prvkey, secp256k1)[1:]
    try:
        return prv_key_tweak_add(internal_prvkey, _tap_tweak(x_P, h))
    except EccValueError as e:
        raise BTClibValueError(str(e)) from e


def output_prvkey_from_merkle_root(prv_key: Integer, merkle_root: Octets = b"") -> int:
    """Return the private key of a taproot output from a merkle root.

    `output_prvkey` with the root already in hand, the shape
    `PSBT_IN_TAP_MERKLE_ROOT` carries it in: a `KeyManager` signing a
    taproot key path spend holds the internal private key and this
    field, never the script tree that produced the root, a psbt naming
    a script path by its leaf and control block instead.
    """
    return _tweaked_prvkey(scalar_from_prv_key(prv_key), bytes_from_octets(merkle_root))


def input_script_sig(
    internal_pubkey: PubKeyData | None,
    script_tree: TaprootScriptTree,
    script_num: int,
) -> tuple[ScriptList, bytes]:
    """Return (leaf script, control block) for a script-path spend.

    `script_num` picks the leaf in tree order, as tree_helper returns
    them; the control block is BIP341's -- parity bit plus leaf
    version, then the x-only internal key, then the merkle path -- and
    a missing internal key is the unspendable point output_pubkey uses.

    In tree order and counting from zero: Python would read -1 as the
    last leaf and hand back a control block that proves it, so a leaf
    named from the wrong end is refused rather than answered.
    """
    # one read of the internal key for the two things this needs of it: the
    # parity of the output key it is tweaked into, and the key itself, which
    # the control block carries. Read twice -- `output_pubkey` and then here
    # -- it was lifted twice on the Python path, and the unspendable point
    # was written out twice besides
    _, parity_bit, pub_key_bytes = _output_pubkey_and_internal_key(
        internal_pubkey, script_tree
    )
    leaves = tree_helper(script_tree)[0]
    if not is_integer(script_num):
        raise BTClibTypeError(f"invalid leaf index type: {type(script_num).__name__}")
    if not 0 <= script_num < len(leaves):
        raise BTClibValueError(f"invalid leaf index: {_message_text(script_num)}")
    (leaf_version, script), path = leaves[script_num]
    control = (parity_bit + leaf_version).to_bytes(1, "big")
    control += pub_key_bytes
    control += path
    return script, control


def check_output_pubkey(q: Octets, script: Octets, control: Octets) -> bool:
    """Answer whether the control block proves the script against the key.

    BIP341's control-block verification: the leaf hash is folded up
    the merkle path in the control block, and the internal key tweaked
    by the result must equal the output key q, parity included. A
    malformed control block or an internal key that is not a point is
    refused rather than answered False, either being no proof at all.
    """
    q = bytes_from_octets(q)
    script = bytes_from_octets(script)
    # the merkle fold below orders two slices of this against a `bytes`
    # digest, and a memoryview does not order against `bytes` where a
    # bytearray does -- the asymmetry is Python's. What the fold reads is
    # the `bytes` `bytes_from_octets` answers with, so no line under it
    # has to know which spelling arrived (issue 1220)
    control = bytes_from_octets(control)
    if len(control) > 33 + 32 * MAX_TREE_DEPTH:
        raise BTClibValueError("control block too long")
    m = (len(control) - 33) // 32
    if len(control) != 33 + 32 * m:
        raise BTClibValueError("invalid control block length")
    k = leaf_hash(control[0] & 0xFE, script)
    for j in range(m):
        e = control[33 + 32 * j : 65 + 32 * j]
        if k < e:
            k = tagged_hash(b"TapBranch", k + e)
        else:
            k = tagged_hash(b"TapBranch", e + k)
    p_bytes = control[1:33]
    t = _tap_tweak(p_bytes, k)
    # libsecp256k1's secp256k1_xonly_pubkey_tweak_add_check is this tweak
    # and a comparison of what it answers. An internal key that is not a
    # point is refused with ecc's class, read into btclib's
    try:
        x_Q, parity = pub_key_tweak_add_var(p_bytes, t)
    except EccValueError as e:
        raise BTClibValueError(str(e)) from e
    return x_Q == int.from_bytes(q, "big") and control[0] & 1 == parity


def assert_valid_control_block(control_block: Octets) -> None:
    """Refuse a control block whose size no leaf depth can produce.

    Size only, and only its residue: one leading byte plus a multiple
    of 32, which BIP341's 33 + 32m sizes all satisfy. Proving the
    block against an output key is check_output_pubkey's.

    The octets first, as check_output_pubkey takes them: `len` of the
    text spelling counts characters, so "e" * 33 -- 33 characters and
    the 66 octets of a hex string -- was a size this accepted, and
    "é" * 33, 33 characters and 66 octets of UTF-8, was a size it
    accepted for no reason at all.
    """
    if (len(bytes_from_octets(control_block)) - 1) % 32 != 0:
        raise BTClibValueError("invalid control block size")
