# Copyright (c) The btclib developers
# Distributed under the MIT software license, see the accompanying
# LICENSE file or https://opensource.org/license/mit for the full text.

"""BIP155's `addrv2`, the `sendaddrv2` that asks for it, and the id table.

The message that gossips an address of any network, and the one a peer
sends to say it understands the first. BIP155 is the specification and
is unusually precise; Core's `CAddress` under `V2_NETWORK`, of
src/protocol.h and src/netaddress.h, is the implementation, and where
the two read differently this module says so and follows the BIP --
except on the length of a `TORV2` or `YGGDRASIL` address, where it
follows Core.

An entry is `addr`'s idea in a different encoding, not a variant of it:
four octets of timestamp, then the service flags as a `CompactSize`, a
one-octet network id, the address as `var_bytes`, and the big-endian
port. Nothing about it is an `addr` entry's octets, and the address field
is not an IP address at all -- a `TORV3` one is an ed25519 public key.

**A class of its own, and one rather than two.** `NetworkAddress` holds
an `ipaddress.IPv6Address`, which a `TORV2`, `TORV3` or `I2P` address is
not, so reuse is refused by the field before it is refused by anything
else: giving that field a union type would put "which of these is it" on
every existing caller of `.ip`, which is the cost issue #1098 declined
when it made `TimestampedNetworkAddress` a second class rather than a
flag on the first. A caller therefore has three types where the protocol
has three encodings -- a `version`'s address, an `addr`'s, and this one --
and the type is what says which message an address came off.

One and not two because BIP155 defines one record: `time` is in its
table unconditionally, no message carries the untimestamped form, and
the split that gave `addr` two classes has nothing here to divide.
`NetworkAddressV2` is therefore the counterpart of
`TimestampedNetworkAddress` rather than of `NetworkAddress`, and "V2" is
Core's word for the encoding -- `CAddress::V2_NETWORK`,
`SerializeV2Stream` -- rather than a second version of the class above
it.

**An unknown network id round-trips.** It is the property the format
exists for: a new network is meant to need no new message, so a parser
that refused an id it had not heard of could not read the message the
next BIP makes ordinary. `_bip155_network_from_int` hands back the plain
`int` where no member names the id, which is what `InventoryType` does
for a type code and the envelope does for a command. Core drops such an
address instead -- `SetNetFromBIP155Network` returns false and
`UnserializeV2Stream` consumes the octets into a default `CNetAddr` --
and it is right to, being a node: BIP155 says clients SHOULD NOT gossip
addresses of networks they cannot validate. That is a rule about what to
relay, and this package relays nothing; keeping the octets is what lets
the caller apply it.

**An address of the wrong length is refused, and the message with it,
under an id Core checks the length of.** BIP155: "Clients SHOULD reject
messages that contain addresses that have a different length than
specified in this table for a specific network ID, as these are
meaningless." Core implements that for `IPV4`, `IPV6`, `TORV3`, `I2P`
and `CJDNS`, the ids `SetNetFromBIP155Network` has a case for, each case
throwing `std::ios_base::failure` on a wrong length, which fails the
whole message rather than the entry. So does `assert_valid` here, for
the same ids, and refusing is what a codec can mean by it: dropping the
entry would leave a message that serializes back one address shorter
than it arrived, and there is no value of a field that means "this one
was ignored".

What BIP155 does say to *ignore* is a different thing, and neither half
of it is refused here: a `TORV2` address, and an `IPV6` address inside a
range reserved for embedding another network -- `::ffff:0:0/96` and
OnionCat's `fd87:d87e:eb43::/48`. Both are receive policy, about whether
an address is worth keeping rather than whether the octets decode, and
Core carries them out by parsing the entry and marking the result
invalid. A parser that refused them would refuse a message Core accepts.
`is_embedded_ipv6` is the second rule as a public predicate, so a caller
applying it does not have to learn the two prefixes for itself.

**`TORV2` and `YGGDRASIL` are in the table, where Core acts on
neither.** BIP155 reserves both, and says "Further network ID numbers
MUST be reserved in a new BIP document", so 3 and 7 mean what they mean
for good. Core names `TORV2` in its own `BIP155Network` and nowhere else
-- `SetNetFromBIP155Network` has no case for it, so an address under it
falls through to the unknown-id path and is dropped, and the test
framework's `ADDRV2_NET_NAME` has no entry for it. `YGGDRASIL` Core has
not got at all, Yggdrasil being carried there as ordinary IPv6, so an id
7 from a real Yggdrasil peer is an unknown network to a Core node today.

So neither id is held to the length BIP155's table gives it. Core reads
an id 3 or id 7 address of any length up to `MAX_ADDRV2_SIZE`, drops it
and keeps the rest of the message; refusing one here would refuse a
message Core accepts, which is the ground on which the receive policy
above is not applied either. The two ids are held to what an unnamed id
is held to, and a caller that wants BIP155's rejection for them applies
the table's ten and sixteen octets itself: keeping the octets is what
lets it.

Naming them is not offering them: an id round-trips whether or not a
member names it, so what the member changes is only whether a caller
reading a captured message sees `BIP155Network.TORV2` or `3` -- and a
table with a hole in it is one somebody eventually reuses. The rule the
tree already follows is `InventoryType`'s: name what the specification
names, and not what it merely reserves for the future.

**The port is big-endian**, as it is in `addr`, and the evidence is not a
round trip: `tests/p2p/addrv2_test.py` is driven by the `addrv2` payload
of Core's own `netbase_tests.cpp`, whose last entry reads port `f1f2` --
61938 one way and 62193 the other.

**The service flags are a `CompactSize` with no range check on it**,
which is the one place btclib's `var_int` default is wrong for this
format. `var_int.parse` caps at Core's `MAX_SIZE`, 33,554,432, because
every var_int btclib otherwise reads is a length or a count; these octets
are a 64-bit bitfield, and Core reads them through
`Using<CompactSizeFormatter<false>>`, the `false` being `RangeCheck`. Bit
25 is 33,554,432 exactly -- inside Core's "reserved for temporary
experiments" range, bits 24 to 31 -- so the default cap starts refusing
peers one bit above it.

**The address itself is opaque octets, and no rendering is offered.**
That is what BIP155 bought: the field's meaning is the network id's, so a
type that decoded it would have to hold every network's format and would
be wrong about the next one. `IPv4Address(entry.address)` and its v6
twin are a caller's one line wherever the octets are an IP address at
all; a `.onion` name is SHA3-256 and a checksum over them, and a
`.b32.i2p` name is base32 of them, neither of which is a codec's work.

**`network_address`, `addr_entry` and `peer_from_addr_entry` are the
translation to and from `btclib.p2p.address`'s two classes, and
`can_addrv1` is the question a caller asks first.** BIP155's record is
the only encoding wide enough for every network a peer can be on, so it
is what a peer is held in, and `addr` is still what a peer that has not
sent `sendaddrv2` is spoken to in: the translation is what stands
between the two. Each is a function of the two types this package
already owns and of the BIP that relates them, which is why it belongs
here rather than beside a socket: `network_address` refuses a network
`addr` cannot carry, on `can_addrv1`'s own question, and `addr_entry`
and `peer_from_addr_entry` are what stand on either side of that
refusal, adding and reading the timestamp `TimestampedNetworkAddress`
carries and `NetworkAddressV2` already has.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from enum import IntEnum
from ipaddress import IPv4Address, IPv6Address

from typing_extensions import override

from btclib import var_bytes, var_int
from btclib.alias import BinaryData, Octets
from btclib.exceptions import BTClibTypeError, BTClibValueError
from btclib.p2p.address import (
    NetworkAddress,
    ServiceFlags,
    TimestampedNetworkAddress,
    _service_flags_from_int,
)
from btclib.p2p.limits import MAX_ADDR_TO_SEND, MAX_ADDRV2_SIZE
from btclib.p2p.payload import Payload, _assert_valid_int
from btclib.utils import (
    _message_text,
    assert_no_trailing,
    bytes_from_octets,
    bytesio_from_binarydata,
    is_integer,
    is_octets,
    read_exactly,
)

__all__ = [
    "AddrV2",
    "BIP155Network",
    "NetworkAddressV2",
    "SendAddrV2",
    "addr_entry",
    "can_addrv1",
    "is_embedded_ipv6",
    "network_address",
    "peer_from_addr_entry",
]

# the fixed-width fields of a BIP155 entry: the services and the address
# are a CompactSize and a var_bytes, so neither has one
_TIMESTAMP_SIZE = 4
_NETWORK_ID_SIZE = 1
_PORT_SIZE = 2

_MAX_TIMESTAMP = (1 << (8 * _TIMESTAMP_SIZE)) - 1
_MAX_NETWORK_ID = (1 << (8 * _NETWORK_ID_SIZE)) - 1
_MAX_PORT = (1 << (8 * _PORT_SIZE)) - 1

# the width of the bitfield the CompactSize carries, which is the cap
# `var_int.parse` is given in place of its own: BIP155 calls `services`
# "a bit field that is 64 bits wide", and Core turns the range check off
# for it rather than raising it
_MAX_SERVICES = (1 << 64) - 1


class BIP155Network(IntEnum):
    """The network an `addrv2` address belongs to, BIP155's id table.

    Every id of that table, spelled as its "Enumeration" column spells
    them. Core's own name for the enum, of src/netaddress.h, taken
    rather than a `NetworkId`: "network" in btclib already means the
    chain -- `btclib.network.Network`, and `btclib.p2p.magic_from_network`
    beside it -- and these are IPv4, Tor and I2P.

    `TORV2` and `YGGDRASIL` are members where Core acts on neither, and
    the module docstring is why. An id no member names is not an error
    either, which is `_bip155_network_from_int`.

    An `IntEnum` and not an `IntFlag`, for the reason `InventoryType` is
    one: these are exclusive kinds and not bits, so composing two of them
    would answer for a network that does not exist.
    """

    IPV4 = 1
    IPV6 = 2
    TORV2 = 3
    TORV3 = 4
    I2P = 5
    CJDNS = 6
    YGGDRASIL = 7


# what BIP155's "Address length (bytes)" column fixes for each id Core's
# `SetNetFromBIP155Network` has a case for, `TORV2` and `YGGDRASIL` being
# out of it for the reason the module docstring gives. A private table
# and not a property of the enum: it is the length of the `addr` field
# rather than anything about the network, and it is what `assert_valid`
# refuses a mismatch against.
#
# Keyed `int` rather than `BIP155Network`, the members being their own
# values: what is looked up here is a `network_id`, which is the plain
# integer wherever no member names it
_ADDRESS_SIZE: dict[int, int] = {
    BIP155Network.IPV4: 4,
    BIP155Network.IPV6: 16,
    BIP155Network.TORV3: 32,
    BIP155Network.I2P: 32,
    BIP155Network.CJDNS: 16,
}


def _bip155_network_from_int(network_id: int) -> BIP155Network | int:
    """Return the member an id names, leaving an unnamed id alone.

    `IntEnum` refuses a value no member has, and an id no member has is
    the whole point of this format: the answer is
    `inventory._inventory_type_from_int`'s, which is to hand the value
    back for `assert_valid` one line later to refuse through this
    library's own exception classes if one octet cannot hold it.

    A bool is handed back rather than converted, `BIP155Network(True)`
    being `IPV4`: `is_integer` is the predicate every integer field of
    this library is held to, and a `network_id=True` that arrived as
    `IPV4` would pass the refusal `assert_valid` exists to make.
    """
    if not is_integer(network_id):
        return network_id
    try:
        return BIP155Network(network_id)
    except ValueError:
        return network_id


@dataclass(frozen=True)
class NetworkAddressV2:
    """One entry of an `addrv2`: a peer, and the network it is on.

    Bitcoin Core's `CAddress` written with `CAddress::V2_NETWORK`, which
    is BIP155's table of fields in its order: `timestamp` in four
    octets little-endian, `services` as a `CompactSize`, `network_id` in
    one octet, `address` as `var_bytes`, and `port` in two octets
    big-endian.

    `address` is the octets and nothing more -- the network id says how
    to read them, and the module docstring is why nothing here does.
    `network_id` is a `BIP155Network` where a member names the id and the
    plain `int` where none does, which is how an address of a network this
    library has not heard of comes back as it arrived. `services` is a
    `ServiceFlags`, which is an `int` carrying the bits it cannot name.

    A `port` of zero is what BIP155 requires where a port means nothing
    for the network, and is a value like any other here.

    Frozen and hashable, every field being immutable: an address is a
    value, it is what an address database keys on, and
    `dataclasses.replace` is what moves one to another port.
    """

    timestamp: int
    services: ServiceFlags
    network_id: BIP155Network | int
    address: bytes
    port: int

    def __init__(
        self,
        timestamp: int = 0,
        services: int = ServiceFlags.NODE_NONE,
        network_id: int = BIP155Network.IPV4,
        address: Octets = b"\x00\x00\x00\x00",
        port: int = 0,
        *,
        check_validity: bool = True,
    ) -> None:
        object.__setattr__(self, "timestamp", timestamp)
        object.__setattr__(self, "services", _service_flags_from_int(services))
        object.__setattr__(self, "network_id", _bip155_network_from_int(network_id))
        object.__setattr__(self, "address", bytes_from_octets(address))
        object.__setattr__(self, "port", port)

        if check_validity:
            self.assert_valid()

    def assert_valid(self) -> None:
        """Refuse a field no width holds, and an address of the wrong length.

        The length is BIP155's table read against `network_id`, for the
        ids Core's `SetNetFromBIP155Network` throws on a mismatch for.
        Any other id fixes nothing -- `TORV2` and `YGGDRASIL`, and an id
        no member names -- so `MAX_ADDRV2_SIZE` is the whole of what such
        an address is held to.
        """
        _assert_valid_int(
            self.timestamp, "timestamp", 0, _MAX_TIMESTAMP, check_validity=True
        )
        _assert_valid_int(
            self.services, "services", 0, _MAX_SERVICES, check_validity=True
        )
        _assert_valid_int(
            self.network_id, "network_id", 0, _MAX_NETWORK_ID, check_validity=True
        )
        _assert_valid_int(self.port, "port", 0, _MAX_PORT, check_validity=True)

        if len(self.address) > MAX_ADDRV2_SIZE:
            err_msg = f"invalid address length: {len(self.address)} bytes"
            err_msg += f" instead of at most {MAX_ADDRV2_SIZE}"
            raise BTClibValueError(err_msg)

        size = _ADDRESS_SIZE.get(self.network_id)
        if size is not None and len(self.address) != size:
            err_msg = f"invalid address length: {len(self.address)} bytes"
            err_msg += f" instead of {size} for network id {int(self.network_id)}"
            raise BTClibValueError(err_msg)

    def serialize(self, *, check_validity: bool = True) -> bytes:
        """Return the entry's octets, the port last and big-endian."""
        if check_validity:
            self.assert_valid()
        else:
            _assert_valid_int(
                self.timestamp, "timestamp", 0, _MAX_TIMESTAMP, check_validity=False
            )
            _assert_valid_int(
                self.services, "services", 0, _MAX_SERVICES, check_validity=False
            )
            _assert_valid_int(
                self.network_id, "network_id", 0, _MAX_NETWORK_ID, check_validity=False
            )
            _assert_valid_int(self.port, "port", 0, _MAX_PORT, check_validity=False)

        out = self.timestamp.to_bytes(_TIMESTAMP_SIZE, byteorder="little", signed=False)
        out += var_int.serialize(int(self.services))
        out += int(self.network_id).to_bytes(
            _NETWORK_ID_SIZE, byteorder="little", signed=False
        )
        out += var_bytes.serialize(self.address)
        # the one big-endian field of this protocol, as it is in `addr`:
        # network byte order, as every port is
        out += self.port.to_bytes(_PORT_SIZE, byteorder="big", signed=False)
        return out

    @classmethod
    def parse(
        cls: type[NetworkAddressV2], data: BinaryData, *, check_validity: bool = True
    ) -> NetworkAddressV2:
        """Return the entry the octets describe, the address bounded first.

        `MAX_ADDRV2_SIZE` is checked off the length field and before the
        read it would size, which is where a bound is worth having: the
        length is the peer's to choose. It does not answer to
        `check_validity`, on `Message.parse`'s reasoning -- a defence a
        caller can turn off is not one -- where the table check in
        `assert_valid` does, being a statement about the address rather
        than about what reading it costs.
        """
        stream = bytesio_from_binarydata(data)

        timestamp = int.from_bytes(
            read_exactly(stream, _TIMESTAMP_SIZE, "address timestamp"),
            byteorder="little",
            signed=False,
        )
        # the cap is the bitfield's width and not `var_int`'s default:
        # these octets are not a length or a count, and Core turns its
        # own range check off for them
        services = var_int.parse(stream, _MAX_SERVICES)
        network_id = int.from_bytes(
            read_exactly(stream, _NETWORK_ID_SIZE, "address network id"),
            byteorder="little",
            signed=False,
        )
        # read by hand where `serialize` above uses `var_bytes`:
        # `var_bytes.parse` reads the length and the octets in one call,
        # and the bound has to stand between the two
        size = var_int.parse(stream)
        if size > MAX_ADDRV2_SIZE:
            err_msg = f"invalid address length: {size} bytes"
            err_msg += f" instead of at most {MAX_ADDRV2_SIZE}"
            raise BTClibValueError(err_msg)
        address = read_exactly(stream, size, "address")
        port = int.from_bytes(
            read_exactly(stream, _PORT_SIZE, "address port"),
            byteorder="big",
            signed=False,
        )
        assert_no_trailing(data, stream, "addrv2 entry")

        return cls(
            timestamp,
            services,
            network_id,
            address,
            port,
            check_validity=check_validity,
        )


# the two ids whose address field is an IP address, which is the whole of
# what an addr version 1 entry can carry
_IP_NETWORKS = (BIP155Network.IPV4, BIP155Network.IPV6)

# BIP155: a client SHOULD ignore an IPV6 entry whose sixteen octets fall
# in a range reserved for embedding another network's address into an
# IPv6 one -- the IPv4 mapping, `::ffff:0:0/96`, and OnionCat's
# `fd87:d87e:eb43::/48`, once used to carry a TORv2 address the same way.
# `IPv6Address.ipv4_mapped` is `ipaddress`'s own name for the first, and
# the second has no name of its own to borrow.
_ONIONCAT_PREFIX = b"\xfd\x87\xd8\x7e\xeb\x43"


def can_addrv1(address: NetworkAddressV2) -> bool:
    """Answer whether an `addr` message has room for this peer.

    Both IP networks and neither of the others: the question is about the
    network being an IP one at all, not about whether the address is
    otherwise worth dialling, which is a node's own policy and not this
    package's.
    """
    return address.network_id in _IP_NETWORKS


def network_address(address: NetworkAddressV2) -> NetworkAddress:
    """Return the untimestamped form of a BIP155 record `can_addrv1` allows.

    What a `version` message's two addresses are, and what an `addr`
    entry is built on. `can_addrv1` is the question a caller asks first;
    the refusal here is what makes the answer binding rather than
    advisory, because the length would not catch it on its own: BIP155
    gives cjdns and yggdrasil the sixteen octets an IPv6 address has, so
    `IPv6Address` would take either for an IP address and hand back a
    peer that is not the one that was gossiped.
    """
    if not can_addrv1(address):
        network_id = _message_text(int(address.network_id))
        err_msg = f"not an ip address: network id {network_id}"
        raise BTClibValueError(err_msg)
    ip = (
        IPv4Address(address.address)
        if address.network_id == BIP155Network.IPV4
        else IPv6Address(address.address)
    )
    return NetworkAddress(address.services, ip, address.port)


def addr_entry(address: NetworkAddressV2) -> TimestampedNetworkAddress:
    """Return the `addr` entry a BIP155 record `can_addrv1` allows."""
    return TimestampedNetworkAddress(address.timestamp, network_address(address))


def peer_from_addr_entry(entry: TimestampedNetworkAddress) -> NetworkAddressV2:
    """Return the BIP155 record an `addr` entry describes.

    An `addr` entry holds every address in sixteen octets, a v4 one
    mapped into them, where BIP155 gives the two networks different ids
    and different lengths: `ip.ipv4_mapped` is what tells them apart, and
    it is why this is not a field rename.
    """
    ip = entry.address.ip
    mapped = ip.ipv4_mapped
    network_id = BIP155Network.IPV4 if mapped else BIP155Network.IPV6
    return NetworkAddressV2(
        entry.timestamp,
        entry.address.services,
        network_id,
        mapped.packed if mapped else ip.packed,
        entry.address.port,
    )


def is_embedded_ipv6(address: NetworkAddressV2) -> bool:
    """Answer whether an `IPV6` record's octets are really another network's.

    BIP155's two ignore rules together: a v4-mapped address, and one
    inside OnionCat's range, once used to carry a TORv2 address the same
    way. Both are receive policy, about whether an address is worth
    keeping rather than whether the octets decode -- the module docstring
    is why `assert_valid` does not apply this -- so it is a caller
    deciding what to keep that does.
    """
    return address.network_id == BIP155Network.IPV6 and (
        IPv6Address(address.address).ipv4_mapped is not None
        or address.address.startswith(_ONIONCAT_PREFIX)
    )


@dataclass(frozen=True)
class AddrV2(Payload):
    """The `addrv2` message: peers of any network, with when they were seen.

    A count and that many `NetworkAddressV2`, which is Core's
    `msg_addrv2` and what `ProcessMessage` reads through the same branch
    it reads an `addr` with, `CAddress::V2_NETWORK` in place of
    `V1_NETWORK` being the whole of the difference there.

    No base shared with `Addr`, where `Inv` and `GetData` have one: those
    two are one body under two commands, and these two are two bodies --
    a `TimestampedNetworkAddress` and a `NetworkAddressV2` are different
    octets, so what a base could hold is the word "count".

    **The count is bounded before anything is built**, at
    `MAX_ADDR_TO_SEND`, which is BIP155's thousand and Core's constant
    for both commands. As in `Addr.parse` the check is off the count and
    before the loop, and it does not answer to `check_validity`.

    A tuple and not a list, so that a frozen `AddrV2` is what its field
    says it is; `dataclasses.replace` is what changes the addresses in one.
    """

    command = "addrv2"

    addresses: tuple[NetworkAddressV2, ...]

    def __init__(
        self,
        addresses: Sequence[NetworkAddressV2] = (),
        *,
        check_validity: bool = True,
    ) -> None:
        # a str and a bytes are Sequences, and each of their elements is
        # what a `NetworkAddressV2` is not: asked whole here, so that a
        # caller who passed one gets a complaint about the argument
        # rather than about its first character. `is_octets` is the four
        # spellings named once, so a spelling `Octets` gains later is
        # refused here too (issue #1420). The declared parameter is
        # already a Sequence[NetworkAddressV2], which mypy reads as never
        # overlapping Octets now that is_octets narrows -- true only of a
        # caller obeying the annotation, which the check exists for the
        # one that does not (issue #1433)
        if is_octets(addresses) or not isinstance(  # type: ignore[redundant-expr]
            addresses, Sequence
        ):
            err_msg = f"invalid addresses type: {type(addresses).__name__}"  # type: ignore[unreachable]
            raise BTClibTypeError(err_msg)
        object.__setattr__(self, "addresses", tuple(addresses))

        if check_validity:
            self.assert_valid()

    def assert_valid(self) -> None:
        """Refuse more addresses than a peer accepts, and ask each of them."""
        if len(self.addresses) > MAX_ADDR_TO_SEND:
            err_msg = f"invalid addresses count: {len(self.addresses)}"
            err_msg += f" instead of at most {MAX_ADDR_TO_SEND}"
            raise BTClibValueError(err_msg)

        for address in self.addresses:
            if not isinstance(address, NetworkAddressV2):
                err_msg = f"invalid address type: {type(address).__name__}"  # type: ignore[unreachable]
                raise BTClibTypeError(err_msg)
            address.assert_valid()

    @override
    def serialize(self, *, check_validity: bool = True) -> bytes:
        """Return the count, then that many BIP155 entries."""
        if check_validity:
            self.assert_valid()

        out = var_int.serialize(len(self.addresses))
        for address in self.addresses:
            out += address.serialize(check_validity=check_validity)
        return out

    @classmethod
    def parse(
        cls: type[AddrV2], data: BinaryData, *, check_validity: bool = True
    ) -> AddrV2:
        """Return the addresses the payload carries, the count bounded first."""
        stream = bytesio_from_binarydata(data)

        count = var_int.parse(stream)
        if count > MAX_ADDR_TO_SEND:
            err_msg = f"invalid addresses count: {count}"
            err_msg += f" instead of at most {MAX_ADDR_TO_SEND}"
            raise BTClibValueError(err_msg)

        addresses = [
            NetworkAddressV2.parse(stream, check_validity=check_validity)
            for _ in range(count)
        ]
        assert_no_trailing(data, stream, "addrv2 payload")

        return cls(addresses, check_validity=check_validity)


@dataclass(frozen=True)
class SendAddrV2(Payload):
    """The `sendaddrv2` message: no fields, and an empty payload.

    Core's `msg_sendaddrv2`, and the whole of that command: a peer that
    sends one is saying it understands `addrv2` and would rather have it
    than `addr`.

    BIP155 puts it in the handshake -- it "MUST only be sent in response
    to the `version` message from a peer and prior to sending the
    `verack` message", and Core disconnects a peer that sends one after
    the `verack`. That is a rule about *when*, which needs a connection to
    hold; this package has none, so the rule is documented here and
    nothing enforces it. The message lives beside `addrv2` rather than in
    `btclib.p2p.handshake` because it is about nothing else.

    `parse` refuses an octet, as `Verack.parse` does and for that class's
    reason: this library refuses what follows an object everywhere else,
    and a `sendaddrv2` with a payload is a message that serializes back
    without it. The two classes repeat three lines rather than share a
    base -- `keepalive._NoncePayload` is a base because two commands have
    one *body*, and the absence of a body is not one to share.
    """

    command = "sendaddrv2"

    def __init__(self, *, check_validity: bool = True) -> None:
        if check_validity:
            self.assert_valid()

    def assert_valid(self) -> None:
        """Accept: a message with no fields has none to refuse."""

    @override
    def serialize(self, *, check_validity: bool = True) -> bytes:
        """Return the empty payload a `sendaddrv2` is."""
        if check_validity:
            self.assert_valid()

        return b""

    @classmethod
    def parse(
        cls: type[SendAddrV2], data: BinaryData, *, check_validity: bool = True
    ) -> SendAddrV2:
        """Return a `SendAddrV2`, refusing any octet at all.

        Octets are refused by `assert_no_trailing`, which is where the
        rule already is; a caller's stream is left exactly where it was,
        a `sendaddrv2` consuming nothing from one.
        """
        stream = bytesio_from_binarydata(data)
        assert_no_trailing(data, stream, "sendaddrv2 payload")

        return cls(check_validity=check_validity)
