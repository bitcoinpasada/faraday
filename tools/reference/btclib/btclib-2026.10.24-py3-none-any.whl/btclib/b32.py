# Copyright (c) The btclib developers
# Distributed under the MIT software license, see the accompanying
# LICENSE file or https://opensource.org/license/mit for the full text.

# Copyright (c) 2017 Pieter Wuille
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
"""Segwit address functions.

**The bitcoin semantics.** p2wpkh, p2wsh and p2tr addresses: the witness
version, the human-readable part of each network, and the length rules a
witness program has to satisfy.

The encoding itself is btclib.bech32, which knows nothing about bitcoin, and
the rule between the two is that direction: this module imports bech32, never
the other way round. `base58` and `b58` are the same pair for the base58
address encoding.

The whole surface is exported, the two facilities below the addresses
included: `power_of_2_base_conversion` is the `convertbits` of the
reference implementation, which a caller reading or writing a witness
program in five-bit groups needs as much as this module does, and
`bytes_from_witness_program` is BIP141's length rule, which `btclib.b58`
asks for the p2sh-wrapped forms.

Some of these functions are originally from
https://github.com/sipa/bech32/tree/master/ref/python,
with the following modifications:

* type annotated Python3
* avoided returning None or (None, None), throwing Exceptions instead
* detailed error messages and extended safety checks
* check that bech32 addresses are not longer than 90 characters,
  a bound bech32.decode deliberately leaves to this module
"""

from __future__ import annotations

import string
from collections.abc import Iterable

from btclib.alias import Octets, String
from btclib.bech32 import decode, encode
from btclib.consensus import MAX_SCRIPT_SIZE
from btclib.exceptions import BTClibTypeError, BTClibValueError
from btclib.hashes import hash160, sha256
from btclib.key import PubKeyData
from btclib.network import NETWORKS, network_from_key_value, network_from_name
from btclib.utils import (
    _message_text,
    assert_type,
    bytes_from_octets,
    is_integer,
    str_from_string,
)

__all__ = [
    "address_from_witness",
    "bytes_from_witness_program",
    "is_segwit_prefixed",
    "p2tr",
    "p2wpkh",
    "p2wsh",
    "power_of_2_base_conversion",
    "witness_from_address",
]

# 0. bech32 facilities


def is_segwit_prefixed(addr: String) -> bool:
    """Answer whether the string starts as a bech32 address of any network.

    The prefix alone -- hrp and the 1 separator -- is read; whether the
    rest decodes is witness_from_address's answer.
    """
    str_addr = str_from_string(addr, "address").strip(string.whitespace).lower()
    return any(str_addr.startswith(f"{net.hrp}1") for net in NETWORKS.values())


def power_of_2_base_conversion(
    data: Iterable[int], from_bits: int, to_bits: int, pad: bool = True
) -> list[int]:
    """Convert a power-of-two digit sequence to another power-of-two base.

    Both widths are positive integers and every value is an integer of at
    most `from_bits` bits, anything else being refused: a wider value
    would come out as the conversion of a different sequence, `[256]`
    from 8 to 5 bits as `[0]` does, and a zero `to_bits` would never
    leave the regrouping loop. A bool is an integer nowhere in this
    library, here included.
    """
    assert_type(pad, bool, "pad")
    for what, width in (("from_bits", from_bits), ("to_bits", to_bits)):
        if not is_integer(width):
            raise BTClibTypeError(f"invalid {what} type: {type(width).__name__}")
        if width < 1:
            raise BTClibValueError(f"invalid {what}: {_message_text(width)} < 1")
    assert_type(data, Iterable, "data")

    values = list(data)
    for value in values:
        if not is_integer(value):
            raise BTClibTypeError(f"invalid value type: {type(value).__name__}")
        if value < 0 or (value >> from_bits):
            raise BTClibValueError(f"invalid value: {_message_text(value)}")
    return _power_of_2_base_conversion(values, from_bits, to_bits, pad)


def _power_of_2_base_conversion(
    data: Iterable[int], from_bits: int, to_bits: int, pad: bool
) -> list[int]:
    # the validating wrapper's work, for a caller whose digits are integers
    # of `from_bits` bits by construction: the octets of a witness program,
    # and the five-bit digits `bech32.decode` looks up in its alphabet
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << to_bits) - 1
    max_acc = (1 << (from_bits + to_bits - 1)) - 1
    for value in data:
        acc = ((acc << from_bits) | value) & max_acc
        bits += from_bits
        while bits >= to_bits:
            bits -= to_bits
            ret.append((acc >> bits) & maxv)

    if pad:
        if bits:
            ret.append((acc << (to_bits - bits)) & maxv)
    elif bits >= from_bits:
        err_msg = f"zero padding of more than {from_bits - 1} bits"
        err_msg += f" in {from_bits}-to-{to_bits} conversion"
        raise BTClibValueError(err_msg)
    elif (acc << (to_bits - bits)) & maxv:
        err_msg = f"non-zero padding in {from_bits}-to-{to_bits} conversion"
        raise BTClibValueError(err_msg)

    return ret


def bytes_from_witness_program(wit_ver: int, wit_prg: Octets) -> bytes:
    """Return the witness program, refusing what BIP141 does not define.

    A version outside 0..16, a program outside 2..40 bytes, or a v0
    program that is neither 20 nor 32 bytes is refused.
    """
    if not 0 <= wit_ver < 17:
        err_msg = "invalid witness version: "
        err_msg += f"{_message_text(wit_ver)} not in 0..16"
        raise BTClibValueError(err_msg)

    if wit_ver == 0:
        return bytes_from_octets(wit_prg, (20, 32))

    return bytes_from_octets(wit_prg, list(range(2, 41)))


# 1. Hash/WitnessProgram from pub_key/script_pub_key
# imported from the hashes module

# 2. bech32 address from WitnessProgram and vice versa


def _address_from_witness(wit_ver: int, wit_prg: Octets, hrp: str) -> str:
    wit_prg = bytes_from_witness_program(wit_ver, wit_prg)
    data = [wit_ver, *_power_of_2_base_conversion(wit_prg, 8, 5, True)]
    bytes_ = encode(hrp, data)
    return bytes_.decode("ascii")


def address_from_witness(
    wit_ver: int, wit_prg: Octets, network: str = "mainnet"
) -> str:
    """Encode a bech32 native segwit address from the witness."""
    hrp = network_from_name(network).hrp
    return _address_from_witness(wit_ver, wit_prg, hrp)


def witness_from_address(b32addr: String) -> tuple[int, bytes, str]:
    """Return the witness from a bech32 native segwit address.

    The returned data structure is: version, program, network.
    """
    # the coercion before the length, which is a fact about characters:
    # `len` of what is neither text nor bytes is a TypeError about a
    # builtin, where the codec below would have named the argument
    addr = str_from_string(b32addr, "address").strip(string.whitespace)

    # the 90-character bound is address semantics, deliberately not
    # enforced by the bech32 codec (Lightning strings exceed it)
    if len(addr) > 90:
        raise BTClibValueError(f"invalid bech32 address length: {len(addr)} > 90")

    hrp, data = decode(addr)

    wit_ver = data[0]
    wit_prog = bytes(_power_of_2_base_conversion(data[1:], 5, 8, False))
    wit_prog = bytes_from_witness_program(wit_ver, wit_prog)

    # check that it is a known segwit address type
    network = network_from_key_value("hrp", hrp)
    if network is None:
        raise BTClibValueError(f"invalid hrp: {hrp}")

    return wit_ver, wit_prog, network


# 1.+2. = 3. bech32 address from pub_key/script_pub_key


def _v0_witness_program_from_key(key: PubKeyData) -> bytes:
    """Return the v0 witness program of a public key.

    hash160 of the SEC octets, and the refusal above it: BIP141 states
    that a version 0 program built from an uncompressed key is
    unspendable, so the three encodings that build one -- `p2wpkh` here,
    `b58.p2wpkh_p2sh` and `script.script_pub_key.ScriptPubKey.p2wpkh` --
    ask this rather than each carrying the rule.

    https://github.com/bitcoin/bips/blob/master/bip-0141.mediawiki
    """
    if not key.is_compressed:
        raise BTClibValueError("not a compressed public key")
    return hash160(key.sec)


def _v0_witness_program_from_script(witness_script: Octets) -> bytes:
    """Return the v0 witness program of a witness script.

    sha256 of the script, refused over MAX_SCRIPT_SIZE bytes for the reason
    `p2wsh` gives. Core's bitcoin-tx refuses the same length with the same
    comparison before wrapping a script in p2wsh. The encodings that build
    one -- `p2wsh` here, `b58.p2wsh_p2sh` and
    `script.script_pub_key.ScriptPubKey.p2wsh` -- ask this rather than each
    carrying the rule.

    The relay limit on a p2wsh witness script, Core's
    MAX_STANDARD_P2WSH_SCRIPT_SIZE, is policy and is not asked here.
    """
    witness_script = bytes_from_octets(witness_script)
    if len(witness_script) > MAX_SCRIPT_SIZE:
        err_msg = "witness script exceeds size limit: "
        err_msg += f"{len(witness_script)} > {MAX_SCRIPT_SIZE}"
        raise BTClibValueError(err_msg)
    return sha256(witness_script)


def p2wpkh(key: PubKeyData) -> str:
    """Return the p2wpkh bech32 address corresponding to a public key."""
    # asked as `b58.p2pkh` asks it, whatever `check_validity` it was built with
    assert_type(key, PubKeyData, "key")
    key.assert_valid()
    return address_from_witness(0, _v0_witness_program_from_key(key), key.network)


def p2wsh(script_pub_key: Octets, network: str = "mainnet") -> str:
    """Return the p2wsh bech32 address corresponding to a script_pub_key.

    The script_pub_key is the witness script, and a witness script over
    MAX_SCRIPT_SIZE bytes is refused, since a spend executes it and Bitcoin Core
    fails a longer segwit v0 script, so the output could never be spent.
    """
    h256 = _v0_witness_program_from_script(script_pub_key)
    return address_from_witness(0, h256, network)


def p2tr(output_key: Octets, network: str = "mainnet") -> str:
    """Return the p2tr bech32 address corresponding to a taproot output key."""
    return address_from_witness(1, output_key, network)
