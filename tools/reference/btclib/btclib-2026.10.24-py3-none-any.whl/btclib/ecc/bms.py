# Copyright (c) The btclib developers
# Distributed under the MIT software license, see the accompanying
# LICENSE file or https://opensource.org/license/mit for the full text.

"""Bitcoin message signing (BMS): address-based signatures over text.

A BMS signature proves control of the private key behind an address.
The scheme is ECDSA under an envelope: the message is prefixed by the
magic "Bitcoin Signed Message:\\n" string -- so that a signed message
can never double as a transaction signature -- and the hash of the
envelope is what is signed. The serialization is the compact 65-byte
[1-byte recovery flag][32-byte r][32-byte s], customarily exchanged
as base64 text, not the DER of transaction signatures.

A vague statement can be replayed out of the context it was signed
for, so a message worth signing names its signer, its date, its
addressee, and its purpose.

The scheme works on key pairs, the address only identifying one: the
signer needs the private key behind the address, from a wallet or
supplied directly. The verifier needs no public key at all, ECDSA
allowing recovery: the candidate keys are implied by the signature,
and the recovery flag says which candidate -- and which address type
-- the signer meant. Explicitly, the recovery flag value is:

    key_id + (4 if compressed else 0) + 27

where:

- key_id is the index in the [0, 3] range identifying which of the
  recovered public keys is the one associated to the address
- compressed indicates if the address is the hash of the compressed
  public key representation
- 27 identifies a p2pkh address, which is the only kind of address
  supported by Bitcoin Core;
  when the recovery flag is in the [31, 34] range of compressed
  addresses, Electrum also checks for p2wpkh-p2sh and p2wpkh
  (segwit always uses compressed public keys);
  BIP137 (Trezor) uses, instead, 35 and 39 instead of 27
  for p2wpkh-p2sh and p2wpkh (respectively)

+----------+---------+-----------------------------------------------------+
| rec flag |  key id | address type                                        |
+==========+=========+=====================================================+
|    27    |    0    | p2pkh uncompressed                                  |
+----------+---------+-----------------------------------------------------+
|    28    |    1    | p2pkh uncompressed                                  |
+----------+---------+-----------------------------------------------------+
|    29    |    2    | p2pkh uncompressed                                  |
+----------+---------+-----------------------------------------------------+
|    30    |    3    | p2pkh uncompressed                                  |
+----------+---------+-----------------------------------------------------+
|    31    |    0    | p2pkh compressed (also Electrum p2wpkh-p2sh/p2wpkh) |
+----------+---------+-----------------------------------------------------+
|    32    |    1    | p2pkh compressed (also Electrum p2wpkh-p2sh/p2wpkh) |
+----------+---------+-----------------------------------------------------+
|    33    |    2    | p2pkh compressed (also Electrum p2wpkh-p2sh/p2wpkh) |
+----------+---------+-----------------------------------------------------+
|    34    |    3    | p2pkh compressed (also Electrum p2wpkh-p2sh/p2wpkh) |
+----------+---------+-----------------------------------------------------+
|    35    |    0    | BIP137 (Trezor) p2wpkh-p2sh                         |
+----------+---------+-----------------------------------------------------+
|    36    |    1    | BIP137 (Trezor) p2wpkh-p2sh                         |
+----------+---------+-----------------------------------------------------+
|    37    |    2    | BIP137 (Trezor) p2wpkh-p2sh                         |
+----------+---------+-----------------------------------------------------+
|    38    |    3    | BIP137 (Trezor) p2wpkh-p2sh                         |
+----------+---------+-----------------------------------------------------+
|    39    |    0    | BIP137 (Trezor) p2wpkh                              |
+----------+---------+-----------------------------------------------------+
|    40    |    1    | BIP137 (Trezor) p2wpkh                              |
+----------+---------+-----------------------------------------------------+
|    41    |    2    | BIP137 (Trezor) p2wpkh                              |
+----------+---------+-----------------------------------------------------+
|    42    |    3    | BIP137 (Trezor) p2wpkh                              |
+----------+---------+-----------------------------------------------------+

This implementation endorses the Electrum approach: a signature
generated with a compressed key (i.e. without explicit address or
with a compressed p2pkh address) is valid also for the
p2wpkh-p2sh and p2wpkh addresses derived from the same key.

The BIP137 behaviour is available all the same: a compressed key
supplemented at signing time with a p2wpkh-p2sh or p2wpkh address
yields a signature valid for that address alone.

The message is signed and verified byte-for-byte as provided:
btclib does not strip whitespace, because the signature must commit
to the exact bytes it names. Bitcoin Core behaves the same
everywhere, its Sign/Verify Message gui dialog included, and so does
the Electrum CLI; the Electrum gui instead deliberately strips
leading and trailing blanks from the message
(https://github.com/spesmilo/electrum/issues/4327), so on a
whitespace-padded message it disagrees with all of the above: a
signature it produces commits to the stripped text, and a signature
over the exact bytes never verifies there. Two mutually exclusive
pull requests put both resolutions in front of Electrum:
https://github.com/spesmilo/electrum/pull/10787 (strip in the one
gui path that misses it, qml signing) and
https://github.com/spesmilo/electrum/pull/10788 (never strip,
matching Core and btclib).

`verify` is the Electrum and BIP137 scheme, and `message_verify` is
Bitcoin Core's: a p2pkh address alone, any first byte, and a signature
of the wrong length or one that recovers no key is an answer, not an
exception.

https://github.com/bitcoin/bitcoin/pull/524

https://github.com/bitcoin/bips/blob/master/bip-0137.mediawiki
"""  # noqa: D301
# the "\n" a few paragraphs up is two characters, backslash and n, naming
# the magic string's own escape notation rather than embedding a newline
# in this one: an r prefix would double that backslash instead

from __future__ import annotations

import base64
import secrets
import string
from dataclasses import dataclass
from enum import Enum
from hashlib import sha256

from ecc.curves import bytes_from_prv_key_int, secp256k1
from ecc.ecc import dsa
from ecc.exceptions import EccRuntimeError

from btclib.alias import BinaryData, Octets, String
from btclib.b32 import is_segwit_prefixed, p2wpkh, witness_from_address
from btclib.b58 import h160_from_address, p2pkh, p2wpkh_p2sh, wif_from_prv_key
from btclib.base58 import decode as b58decode
from btclib.exceptions import BTClibRuntimeError, BTClibValueError
from btclib.hashes import hash160, magic_message
from btclib.key import PrvKeyData, PubKeyData
from btclib.network import network_from_name
from btclib.utils import (
    _message_text,
    assert_no_trailing,
    assert_type,
    bytesio_from_binarydata,
    str_from_string,
)

__all__ = [
    "MessageVerificationResult",
    "Sig",
    "assert_as_valid",
    "gen_keys",
    "message_verify",
    "sign",
    "verify",
]

_REQUIRED_LENGTH = 65


@dataclass(frozen=True, init=False)
class Sig:
    """A Bitcoin Message Signature: recovery flag and ECDSA signature.

    The flag, 27 to 42, carries the recovery key id and the address
    type the signer claims; the signature is an ordinary dsa.Sig on
    secp256k1. The wire form is the 65-byte compact serialization,
    customarily exchanged as base64 (b64encode/b64decode).
    """

    # 1 byte
    rf: int
    dsa_sig: dsa.Sig

    # written out rather than an InitVar[bool] field and a __post_init__:
    # see the comment on dsa.Sig.__init__
    def __init__(
        self, rf: int, dsa_sig: dsa.Sig, *, check_validity: bool = True
    ) -> None:
        object.__setattr__(self, "rf", rf)
        object.__setattr__(self, "dsa_sig", dsa_sig)

        if check_validity:
            self.assert_valid()

    def assert_valid(self) -> None:
        """Refuse a flag outside 27..42, a curve that is not secp256k1."""
        if self.rf < 27 or self.rf > 42:
            raise BTClibValueError(f"invalid recovery flag: {_message_text(self.rf)}")
        self.dsa_sig.assert_valid()
        if self.dsa_sig.ec != secp256k1:
            raise BTClibValueError(f"invalid curve: {self.dsa_sig.ec.name}")

    def serialize(self, *, check_validity: bool = True) -> bytes:
        """Return the 65-byte compact form: flag, then r, then s."""
        if check_validity:
            self.assert_valid()

        # [1-byte recovery flag][32-bytes r][32-bytes s]
        n_size = self.dsa_sig.ec.n_size
        return b"".join(
            [
                self.rf.to_bytes(1, byteorder="big", signed=False),
                self.dsa_sig.r.to_bytes(n_size, byteorder="big", signed=False),
                self.dsa_sig.s.to_bytes(n_size, byteorder="big", signed=False),
            ]
        )

    def b64encode(self, *, check_validity: bool = True) -> str:
        """Return the BMS address-based signature as base64-encoding.

        First off, the signature is serialized in the [1-byte
        rf][32-bytes r][32-bytes s] compact format, then it is
        base64-encoded.
        """
        data_binary = self.serialize(check_validity=check_validity)
        return base64.b64encode(data_binary).decode("ascii")

    @classmethod
    def parse(cls: type[Sig], data: BinaryData, *, check_validity: bool = True) -> Sig:
        """Build a Sig from the 65-byte compact serialization."""
        stream = bytesio_from_binarydata(data)
        sig_bin = stream.read(_REQUIRED_LENGTH)

        # the length is checked whatever check_validity says: it is not
        # an opinion about the signature, it is what makes the slices
        # below mean anything. Skipped, a short buffer would still yield
        # a Sig, r and s coming from truncated slices -- every input
        # sharing a prefix mapping to the same signature
        if len(sig_bin) != _REQUIRED_LENGTH:
            err_msg = f"invalid decoded length: {len(sig_bin)}"
            err_msg += f" instead of {_REQUIRED_LENGTH}"
            raise BTClibValueError(err_msg)
        assert_no_trailing(data, stream, "signature")

        rf = sig_bin[0]
        ec = secp256k1
        n_size = ec.n_size
        r = int.from_bytes(sig_bin[1 : 1 + n_size], "big", signed=False)
        s = int.from_bytes(sig_bin[1 + n_size : 1 + 2 * n_size], "big", signed=False)
        dsa_sig = dsa.Sig(r, s, ec, check_validity=False)

        return cls(rf, dsa_sig, check_validity=check_validity)

    @classmethod
    def b64decode(cls: type[Sig], data: String, *, check_validity: bool = True) -> Sig:
        """Return the verified components of the provided BMS signature.

        The address-based BMS signature can be represented as (rf, r, s)
        tuple or as base64-encoding of the compact format [1-byte
        rf][32-bytes r][32-bytes s].
        """
        # b64decode discards whatever is not in the base64 alphabet,
        # which would make a signature reachable from unboundedly many
        # strings. validate=True rejects that junk, but it is not enough
        # on its own: what it makes of padding depends on the
        # interpreter -- 3.11 takes the excess pad of "AAAA===" and the
        # pad after a complete group in "QUJD=" that 3.12 and later
        # refuse -- and every version discards the bits a non-final
        # group leaves over. What settles it everywhere is requiring the
        # canonical encoding, the one b64encode gives back.
        # the coercion before the strip, which is str's and bytes': what
        # is neither reached it untouched, so `bms.verify` handed a type
        # of its own choosing left as an AttributeError about a missing
        # method (issue #814). Stripping then covers what came as bytes
        # as well as what came as text: the whitespace around a copied
        # and pasted signature is the one laxity worth tolerating
        text = str_from_string(data, "base64 signature").strip(string.whitespace)
        try:
            data_bin = text.encode("ascii")
            data_decoded = base64.b64decode(data_bin, validate=True)
        except ValueError as e:  # binascii.Error and UnicodeEncodeError
            raise BTClibValueError(f"invalid base64 encoding: {e}") from e
        if base64.b64encode(data_decoded) != data_bin:
            raise BTClibValueError("invalid base64 encoding: not canonical")
        return cls.parse(data_decoded, check_validity=check_validity)


def gen_keys(network: str = "mainnet", compressed: bool = True) -> tuple[str, str]:
    """Return a private/public key pair, drawn on the network's curve.

    The private key is a WIF, the public key is a base58 p2pkh address.
    """
    ec = network_from_name(network).curve
    # q in the range [1, ec.n-1]
    q = 1 + secrets.randbelow(ec.n - 1)
    # `wif_from_prv_key` is what refuses a `compressed` that is no bool,
    # ahead of the derivation below reading it
    wif = wif_from_prv_key(q, network, compressed)
    sec = bytes_from_prv_key_int(q, ec, compressed)
    # check_validity=False: the octets are the serialization just made,
    # and the network is the one they were drawn on
    return wif, p2pkh(PubKeyData(sec, network, check_validity=False))


def sign(msg: Octets, prv_key: PrvKeyData, addr: String | None = None) -> Sig:
    """Generate address-based compact signature for the provided message.

    The key is the parsed form and not a spelling of one. What signs is
    the scalar, and what names the address is the network and the
    compression flag beside it -- the three a WIF carries, which
    `b58.prv_key_data_from_wif` reads once, and which a caller holding a
    scalar states with `PrvKeyData(q, network, compressed)`.
    """
    # asked here whatever `check_validity` the object was built with: a
    # key the constructor was told not to check is one a caller may hold
    assert_type(prv_key, PrvKeyData, "prv_key")
    prv_key.assert_valid()
    magic_msg = magic_message(msg)
    q, network, compressed = prv_key.q, prv_key.network, prv_key.compressed

    # signing and naming the key_id are one call, not two, and this module
    # has no dispatch of its own for it: `dsa.sign_recoverable` answers the
    # key_id whichever implementation signs, the recid libsecp256k1
    # reports being the very thing the Python signer computes anyway --
    # the parity of the nonce's point and how far its x-coordinate runs
    # past the group order. Not a search over the four candidates, one
    # recovery each until one is the signer's own key: that recomputes
    # what the signer already knows, on either path (issue 285)
    dsa_sig, key_id = dsa.sign_recoverable(magic_msg, q)

    # bytes_from_prv_key_int, not bytes_from_point(mult(q)): the address
    # wants the octets, and on secp256k1 they come out of the bindings'
    # own serialization without a point in between (issue #127)
    # check_validity=False: the octets are the serialization above, and
    # the network is the one the key says it is on
    pub_key = PubKeyData(
        bytes_from_prv_key_int(q, compressed=compressed),
        network,
        check_validity=False,
    )

    if addr is not None:
        addr = str_from_string(addr, "address").strip(string.whitespace)

    # finally, calculate the recovery flag
    if addr is None or addr == p2pkh(pub_key):
        rf = key_id + 27
        # third bit in rf is reserved for the 'compressed' boolean
        rf += 4 if compressed else 0
    # BIP137, and only for a compressed key: both spellings are segwit,
    # which has no uncompressed form, so an uncompressed key can own a
    # p2pkh address and nothing else. Without the guard the two calls
    # below would be reached with an uncompressed pub_key and raise out
    # of p2wpkh_p2sh -- "not a compressed public key", which says what
    # the key is and not what failed, the address simply not being this
    # key's
    elif compressed and addr == p2wpkh_p2sh(pub_key):
        rf = key_id + 35
    elif compressed and addr == p2wpkh(pub_key):
        rf = key_id + 39
    else:
        raise BTClibValueError("mismatch between private key and address")

    return Sig(rf, dsa_sig)


def _assert_p2wpkh(addr: String, rf: int, pub_key: bytes) -> None:
    """Raise an exception unless the p2wpkh address is this key's.

    The recovery flag has to be one that names a native segwit address,
    which is two ranges and not one: 39..42, the spelling BIP137
    assigns to p2wpkh, and 31..34, the compressed p2pkh spelling, which
    is accepted because Electrum signs a native address with it.
    """
    wit_ver, h160, _ = witness_from_address(addr)
    if wit_ver != 0 or len(h160) != 20:
        raise BTClibValueError(f"not a p2wpkh address: {addr!r}")
    if not (30 < rf < 35 or rf > 38):
        raise BTClibValueError(f"invalid p2wpkh address recovery flag: {rf}")
    if hash160(pub_key) != h160:
        raise BTClibValueError(f"invalid p2wpkh address: {addr!r}")


def _assert_p2pkh(addr: String, rf: int, pub_key: bytes, h160: bytes) -> None:
    """Raise an exception unless the p2pkh address is this key's.

    27..34, i.e. everything below the first segwit spelling: p2pkh is
    the only address type an uncompressed key can own, so it is the only
    one whose flags include the uncompressed 27..30.
    """
    if rf > 34:
        raise BTClibValueError(f"invalid p2pkh address recovery flag: {rf}")
    if hash160(pub_key) != h160:
        raise BTClibValueError(f"invalid p2pkh address: {addr!r}")


def _assert_p2wpkh_p2sh(addr: String, rf: int, pub_key: bytes, h160: bytes) -> None:
    """Raise an exception unless the p2wpkh-p2sh address is this key's.

    31..38: the 35..38 BIP137 assigns to the wrapped spelling, and again
    the compressed p2pkh 31..34 that Electrum signs it with. Segwit
    either way, so an uncompressed key cannot own one.
    """
    if not 30 < rf < 39:
        raise BTClibValueError(f"invalid p2wpkh-p2sh address recovery flag: {rf}")
    script_pk = b"\x00\x14" + hash160(pub_key)
    if hash160(script_pk) != h160:
        raise BTClibValueError(f"invalid p2wpkh-p2sh address: {addr!r}")


def assert_as_valid(msg: Octets, addr: String, sig: Sig | String) -> None:
    """Refuse a signature that does not open to the address.

    The public key is recovered from the signature under the magic
    message envelope, then rendered as the address type the recovery
    flag claims; anything short of a match is an error, verify being
    the boolean answer.
    """
    if isinstance(sig, Sig):
        sig.assert_valid()
    else:
        sig = Sig.b64decode(sig)

    # first two bits in rf are reserved for key_id
    #    key_id = 00;     key_id = 01;     key_id = 10;     key_id = 11
    # 27-27 = 000000;  28-27 = 000001;  29-27 = 000010;  30-27 = 000011
    # 31-27 = 000100;  32-27 = 000101;  33-27 = 000110;  34-27 = 000111
    # 35-27 = 001000;  36-27 = 001001;  37-27 = 001010;  38-27 = 001011
    # 39-27 = 001100;  40-27 = 001101;  41-27 = 001110;  42-27 = 001111
    key_id = sig.rf - 27 & 0b11
    magic_msg = magic_message(msg)
    compressed = sig.rf > 30
    # signature is valid only if the provided address is matched, and an
    # address is a hash of the sec octets: `recover_sec` answers the
    # octets, which where the bindings serve they write themselves, no
    # point being built
    pub_key = dsa.recover_sec(
        key_id, magic_msg, sig.dsa_sig, sha256, compressed=compressed
    )

    # the address says which of the three checks applies, and each of them
    # carries the recovery-flag range that belongs to its type: the flag
    # is what the signer said the address was, so a flag outside the range
    # is a signature for a different address type
    if is_segwit_prefixed(addr):
        _assert_p2wpkh(addr, sig.rf, pub_key)
        return

    script_type, h160, _ = h160_from_address(addr)

    if script_type == "p2pkh":
        _assert_p2pkh(addr, sig.rf, pub_key, h160)
        return

    # must be p2wpkh-p2sh
    _assert_p2wpkh_p2sh(addr, sig.rf, pub_key, h160)


def _assert_structurally_valid_(addr: String, sig: Sig | String) -> Sig:
    """Raise for an address or a signature that cannot possibly be one.

    Ahead of the try that turns everything else -- a recovery flag
    outside 27..42, a scalar out of range, an address of the wrong type
    for the flag, an address that is simply another key's -- into False
    (issue 2170).

    The address is this scheme's public key: nothing else names the
    signer, the candidate keys being recovered from the signature
    itself. So a string that decodes to no address at all is the same
    unanswerable question `dsa.verify` refuses for a key spelling that
    is no key, and it is refused the same way, by the very parse
    `assert_as_valid` dispatches on. What *is* an address and simply
    does not belong to this signature -- another key's, or a type the
    recovery flag does not name -- stays False: those are answers about
    the signature.

    The compact serialization is 65 octets and no other length is one,
    so a base64 spelling that is not canonical, or that decodes to
    anything else, raises here. `check_validity=False` leaves the value
    half of the signature where it belongs: a recovery flag outside
    27..42 and an r or an s out of range are carried by a well-formed
    65-octet signature, so `assert_as_valid` answers them below, on the
    `Sig` this returns.

    The message is not asked here, as in `ecc.ecc.dsa` and
    `ecc.ecc.ssa`: it is what the signature is verified about, and
    issue #814 is where that was settled.
    """
    parsed_sig = (
        sig if isinstance(sig, Sig) else Sig.b64decode(sig, check_validity=False)
    )
    if is_segwit_prefixed(addr):
        witness_from_address(addr)
    else:
        h160_from_address(addr)
    return parsed_sig


def verify(msg: Octets, addr: String, sig: Sig | String) -> bool:
    """Verify address-based compact signature for the provided message.

    The Electrum and BIP137 scheme; `message_verify` is Bitcoin Core's.

    Raises where the address or the signature is structurally invalid --
    no address at all, or octets no compact signature has -- and answers
    False for a well-formed pair that is merely not authentic. See
    `_assert_structurally_valid_`.
    """
    parsed_sig = _assert_structurally_valid_(addr, sig)
    # ValueError and the two RuntimeErrors, btclib's and that of
    # ecc, which recovers the key: a well-formed signature that
    # does not open to the address is False, and so is a recovery flag
    # or a scalar out of range; a caller's own mistake in the address or
    # in the signature's encoding is refused above rather than excluded
    # from the except
    try:
        assert_as_valid(msg, addr, parsed_sig)
    except (ValueError, BTClibRuntimeError, EccRuntimeError):
        return False

    return True


class MessageVerificationResult(Enum):
    """The answer of Bitcoin Core's `MessageVerify`, member for member.

    Core's `verifymessage` raises for the first three errors and answers
    false for the last two.
    """

    OK = "ok"
    ERR_INVALID_ADDRESS = "invalid address"
    ERR_ADDRESS_NO_KEY = "address does not refer to key"
    ERR_MALFORMED_SIGNATURE = "malformed base64 encoding"
    ERR_PUBKEY_NOT_RECOVERED = "public key not recovered"
    ERR_NOT_SIGNED = "message not signed with the address key"


def _core_text(value: String, what: str) -> str:
    """Return the text of a String; a byte outside ASCII stays a character.

    Core's strings are bytes. One outside ASCII is in no alphabet, so it
    is refused later as any other character is, rather than here.
    """
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).decode("latin-1")
    return str_from_string(value, what)


def _is_core_segwit(addr: str, hrp: str) -> bool:
    """Answer whether the address is a segwit one of the hrp, as Core reads it.

    Core's bech32 reader skips no white space, where `witness_from_address`
    trims it.
    """
    if addr != addr.strip(string.whitespace):
        return False
    try:
        _, _, found = witness_from_address(addr)
    except BTClibValueError:
        return False
    return network_from_name(found).hrp == hrp


def _core_key_hash(addr: str, network: str) -> bytes | MessageVerificationResult:
    """Return the key hash of a p2pkh address, as `DecodeDestination` reads it.

    Anything else is the refusal Core gives it: an address of no kind is
    invalid, a p2sh or a segwit one does not refer to a key. Core's base58
    reader skips ASCII white space around the address, and the first
    characters tell which of the two readers reads it.
    """
    net = network_from_name(network)
    if addr[: len(net.hrp)].lower() == net.hrp:
        if _is_core_segwit(addr, net.hrp):
            return MessageVerificationResult.ERR_ADDRESS_NO_KEY
        return MessageVerificationResult.ERR_INVALID_ADDRESS

    try:
        payload = b58decode(addr.strip(string.whitespace), 21)
    except BTClibValueError:
        return MessageVerificationResult.ERR_INVALID_ADDRESS
    if payload[:1] == net.p2pkh:
        return payload[1:]
    if payload[:1] == net.p2sh:
        return MessageVerificationResult.ERR_ADDRESS_NO_KEY
    return MessageVerificationResult.ERR_INVALID_ADDRESS


def _core_decode_base64(text: str) -> bytes | None:
    """Return the bytes of a base64 text as Core's `DecodeBase64` reads it.

    That reader takes the canonical spelling and nothing else: no white
    space, nothing outside the alphabet, padding to a multiple of four,
    and no bit left over that is not zero. The canonical spelling is what
    `b64encode` gives back, which is also what settles the padding the
    interpreters read differently (see `Sig.b64decode`).
    """
    try:
        data = text.encode("ascii")
        decoded = base64.b64decode(data, validate=True)
    except ValueError:  # binascii.Error and UnicodeEncodeError
        return None
    return decoded if base64.b64encode(decoded) == data else None


def message_verify(
    msg: Octets,
    addr: String,
    sig: String,
    *,
    network: str = "mainnet",
) -> MessageVerificationResult:
    """Verify a message signature exactly as Bitcoin Core's `MessageVerify`.

    Core's rules, which are not those of `verify` (Electrum and BIP137):

    - the address is a p2pkh one of the network, and no other kind
    - the signature is base64 in its canonical spelling, white space
      included as a refusal
    - any first byte is read: `(byte - 27) & 3` is the recovery id and
      `(byte - 27) & 4` says the key is compressed
    - a signature of another length than 65 bytes, a scalar out of range
      and a recovery that finds no key recover no key

    The refusals are values and not exceptions, so that a caller answering
    as Core's `verifymessage` maps each member as it likes. A value it
    cannot read as what it declares raises -- a wrong type, an unknown
    network, a message that is not octets: that is the caller's mistake,
    not an answer.

    Read at bitcoin/bitcoin@9be056a8a7 (v31.1): `MessageVerify` in
    `src/common/signmessage.cpp`, `DecodeBase64` in
    `src/util/strencodings.cpp`, `CPubKey::RecoverCompact` in
    `src/pubkey.cpp`.
    """
    # the types first, whatever the answer: the caller's own mistake
    magic_msg = magic_message(msg)
    str_addr = _core_text(addr, "address")
    str_sig = _core_text(sig, "signature")

    key_hash = _core_key_hash(str_addr, network)
    if isinstance(key_hash, MessageVerificationResult):
        return key_hash

    sig_bytes = _core_decode_base64(str_sig)
    if sig_bytes is None:
        return MessageVerificationResult.ERR_MALFORMED_SIGNATURE
    if len(sig_bytes) != _REQUIRED_LENGTH:
        return MessageVerificationResult.ERR_PUBKEY_NOT_RECOVERED

    flag = sig_bytes[0] - 27
    dsa_sig = dsa.Sig(
        int.from_bytes(sig_bytes[1:33], "big"),
        int.from_bytes(sig_bytes[33:], "big"),
        secp256k1,
        check_validity=False,
    )
    try:
        pub_key = dsa.recover_sec(
            flag & 0b11, magic_msg, dsa_sig, sha256, compressed=bool(flag & 0b100)
        )
    except (ValueError, BTClibRuntimeError, EccRuntimeError):
        return MessageVerificationResult.ERR_PUBKEY_NOT_RECOVERED

    if hash160(pub_key) != key_hash:
        return MessageVerificationResult.ERR_NOT_SIGNED
    return MessageVerificationResult.OK
