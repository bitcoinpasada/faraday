# Copyright (c) The btclib developers
# Distributed under the MIT software license, see the accompanying
# LICENSE file or https://opensource.org/license/mit for the full text.

"""ElligatorSwift encoding of a public key, and BIP324's x-only ECDH on it.

The encoding itself, `create`, `encode_var` and `decode_var`, is
`ecc.ecc.ellswift`'s. What BIP324 builds on the map is a protocol's
rather than a fact about a curve, and it is this module's: `xdh`, the
x-only ECDH over two encodings, with `XDH_TAG` and `ELL_SIZE`.

https://github.com/bitcoin/bips/blob/master/bip-0324.mediawiki

This module stops at the x-only ECDH. The cipher and the packet layer of
BIP324's v2 transport are `btclib.p2p.bip324`, behind the `bip324`
extra. The key schedule's HKDF-SHA256 is a construction over a hash,
`hmac` and `hashlib` and nothing else, and it is `ecc.kdf.hkdf`.

- **ChaCha20-Poly1305** is the cipher, and `ecc.ecc.ecies` is where
  the rule about a cipher is stated: btclib writes none. A hand-rolled one
  would be the only implementation, on by default, for every installation,
  on a network path, so `btclib.p2p.bip324` uses `cryptography`'s, which
  the extra installs.
- **Forward-secure rekeying, length obfuscation and packet framing** are
  in `btclib.p2p.bip324`, held to BIP324's packet vectors. The handshake,
  the garbage and the connection are a P2P client's, which btclib does
  not provide.
"""

from __future__ import annotations

from ecc.curves import Curve, mult, scalar_from_prv_key, secp256k1
from ecc.ecc import ellswift as _ecc_ellswift
from ecc.hashes import tagged_hash

from btclib.alias import Integer, Octets
from btclib.exceptions import BTClibValueError
from btclib.utils import assert_type, bytes_from_octets

__all__ = [
    "ELL_SIZE",
    "XDH_TAG",
    "xdh",
]

# two field elements of secp256k1, which is what BIP324 fixes the size
# at; `xdh` takes 2 * ec.p_size, the same number for it
ELL_SIZE = 64

# BIP324's tag for the hash the shared x-coordinate goes through
XDH_TAG = b"bip324_ellswift_xonly_ecdh"


def _ell_from_octets(ell: Octets, ec: Curve) -> bytes:
    """Return the encoding as the octets the hash reads, size checked."""
    assert_type(ec, Curve, "ec")
    ell = bytes_from_octets(ell)
    if len(ell) != 2 * ec.p_size:
        err_msg = f"invalid ElligatorSwift size: {len(ell)}"
        err_msg += f" instead of {2 * ec.p_size} bytes"
        raise BTClibValueError(err_msg)
    return ell


def xdh(
    ell_a: Octets,
    ell_b: Octets,
    prv_key: Integer,
    party: int,
    ec: Curve = secp256k1,
) -> bytes:
    """Return the x-only ECDH shared secret of two ElligatorSwift keys.

    `party` says which of the two encodings is the caller's -- 0 for
    ell_a, 1 for ell_b -- because the secret is a hash of both encodings
    in a fixed order, and the other one is the key to multiply. The
    correspondence between the private key and the caller's encoding is
    not checked: the two parties reach the same 32 bytes when it holds,
    and nothing here can tell that it does.

    `decode_var` and `mult` run on the bindings for secp256k1 where they
    serve, and that `mult` is constant-time in the key.
    """
    ell_a = _ell_from_octets(ell_a, ec)
    ell_b = _ell_from_octets(ell_b, ec)
    if party not in {0, 1}:
        # the value is not quoted: with the arguments swapped it is the key
        raise BTClibValueError("invalid party, not 0 (A) or 1 (B)")
    q = scalar_from_prv_key(prv_key, ec)

    # the shared x-coordinate is the same for either y of the decoded
    # point, q*P and q*(-P) differing by their own y alone, so which y
    # `decode_var` answers with does not reach the secret
    x = mult(q, _ecc_ellswift.decode_var(ell_b if party == 0 else ell_a, ec), ec)[0]
    preimage = ell_a + ell_b + x.to_bytes(ec.p_size, byteorder="big", signed=False)
    return tagged_hash(XDH_TAG, preimage)
